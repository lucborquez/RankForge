package com.esports.auth_service.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// @Configuration: Spring lee esta clase al arrancar y registra el bean para springdoc.
@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Auth Service API")
                        .version("1.0.0")
                        .description("Microservicio de autenticacion y gestion de cuentas de acceso (login, registro, roles, JWT) de eSports Arena Manager.")
                        .contact(new Contact()
                                .name("eSports Arena Manager Team")));
    }
}
