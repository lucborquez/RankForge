package com.esports.auth_service.service;

import com.esports.auth_service.dto.CuentaRequestDTO;
import com.esports.auth_service.dto.CuentaResponseDTO;
import com.esports.auth_service.dto.LoginRequestDTO;
import com.esports.auth_service.dto.LoginResponseDTO;
import com.esports.auth_service.model.CuentaAcceso;
import com.esports.auth_service.repository.CuentaAccesoRepository;
import com.esports.auth_service.util.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.time.LocalDate;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Pruebas unitarias de AuthService.
 *
 * Se simulan 3 dependencias: el repositorio (JPA), el PasswordEncoder (BCrypt) y
 * JwtUtil (generacion de tokens). Asi probamos la regla de negocio de login/registro
 * sin tocar base de datos real ni generar tokens JWT reales.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("AuthService - pruebas unitarias")
class AuthServiceTest {

    @Mock
    private CuentaAccesoRepository cuentaRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private AuthService authService;

    private CuentaAcceso cuentaExistente;

    @BeforeEach
    void setUp() {
        cuentaExistente = new CuentaAcceso();
        cuentaExistente.setId(1L);
        cuentaExistente.setEmail("jugador@esports.com");
        cuentaExistente.setPasswordHash("hash-encriptado");
        cuentaExistente.setRol("JUGADOR");
        cuentaExistente.setEstado(true);
        cuentaExistente.setFechaCreacion(LocalDate.now());
    }

    @Test
    @DisplayName("registrar() debe encriptar la password y guardar la cuenta cuando el email no existe")
    void registrar_conEmailDisponible_creaLaCuenta() {
        // Given
        CuentaRequestDTO dto = new CuentaRequestDTO();
        dto.setEmail("nuevo@esports.com");
        dto.setPassword("123456");
        dto.setRol("JUGADOR");

        when(cuentaRepository.findByEmail("nuevo@esports.com")).thenReturn(Optional.empty());
        when(passwordEncoder.encode("123456")).thenReturn("hash-123456");
        when(cuentaRepository.save(any(CuentaAcceso.class))).thenAnswer(inv -> {
            CuentaAcceso c = inv.getArgument(0);
            c.setId(2L);
            return c;
        });

        // When
        CuentaResponseDTO resultado = authService.registrar(dto);

        // Then
        assertThat(resultado.getId()).isEqualTo(2L);
        assertThat(resultado.getEmail()).isEqualTo("nuevo@esports.com");
        verify(passwordEncoder).encode("123456");
        verify(cuentaRepository).save(argThat(c -> c.getPasswordHash().equals("hash-123456")));
    }

    @Test
    @DisplayName("registrar() debe fallar si el email ya esta en uso")
    void registrar_conEmailDuplicado_lanzaExcepcion() {
        CuentaRequestDTO dto = new CuentaRequestDTO();
        dto.setEmail("jugador@esports.com");
        dto.setPassword("123456");
        dto.setRol("JUGADOR");

        when(cuentaRepository.findByEmail("jugador@esports.com")).thenReturn(Optional.of(cuentaExistente));

        assertThatThrownBy(() -> authService.registrar(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Ya existe una cuenta");

        verify(cuentaRepository, never()).save(any());
    }

    @Test
    @DisplayName("login() debe devolver un token cuando las credenciales son correctas")
    void login_conCredencialesCorrectas_devuelveToken() {
        LoginRequestDTO dto = new LoginRequestDTO();
        dto.setEmail("jugador@esports.com");
        dto.setPassword("123456");

        when(cuentaRepository.findByEmail("jugador@esports.com")).thenReturn(Optional.of(cuentaExistente));
        when(passwordEncoder.matches("123456", "hash-encriptado")).thenReturn(true);
        when(jwtUtil.generarToken("jugador@esports.com", "JUGADOR")).thenReturn("token-falso-123");

        LoginResponseDTO resultado = authService.login(dto);

        assertThat(resultado.getToken()).isEqualTo("token-falso-123");
        assertThat(resultado.getRol()).isEqualTo("JUGADOR");
    }

    @Test
    @DisplayName("login() debe fallar si la contraseña no coincide")
    void login_conPasswordIncorrecta_lanzaExcepcion() {
        LoginRequestDTO dto = new LoginRequestDTO();
        dto.setEmail("jugador@esports.com");
        dto.setPassword("clave-mala");

        when(cuentaRepository.findByEmail("jugador@esports.com")).thenReturn(Optional.of(cuentaExistente));
        when(passwordEncoder.matches("clave-mala", "hash-encriptado")).thenReturn(false);

        assertThatThrownBy(() -> authService.login(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Credenciales incorrectas");

        verify(jwtUtil, never()).generarToken(any(), any());
    }

    @Test
    @DisplayName("login() debe fallar si el email no esta registrado")
    void login_conEmailInexistente_lanzaExcepcion() {
        LoginRequestDTO dto = new LoginRequestDTO();
        dto.setEmail("fantasma@esports.com");
        dto.setPassword("123456");

        when(cuentaRepository.findByEmail("fantasma@esports.com")).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.login(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Credenciales incorrectas");
    }

    @Test
    @DisplayName("login() debe fallar si la cuenta esta desactivada, aunque la password sea correcta")
    void login_conCuentaDesactivada_lanzaExcepcion() {
        cuentaExistente.setEstado(false);

        LoginRequestDTO dto = new LoginRequestDTO();
        dto.setEmail("jugador@esports.com");
        dto.setPassword("123456");

        when(cuentaRepository.findByEmail("jugador@esports.com")).thenReturn(Optional.of(cuentaExistente));

        assertThatThrownBy(() -> authService.login(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("cuenta está desactivada");

        // No debe ni intentar comparar la password si la cuenta ya esta desactivada
        verify(passwordEncoder, never()).matches(any(), any());
    }

    @Test
    @DisplayName("desactivar() debe poner estado=false y guardar la cuenta")
    void desactivar_conIdExistente_marcaComoInactiva() {
        when(cuentaRepository.findById(1L)).thenReturn(Optional.of(cuentaExistente));

        authService.desactivar(1L);

        verify(cuentaRepository).save(argThat(c -> !c.getEstado()));
    }

    @Test
    @DisplayName("buscarPorId() debe lanzar excepcion si la cuenta no existe")
    void buscarPorId_conIdInexistente_lanzaExcepcion() {
        when(cuentaRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> authService.buscarPorId(404L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Cuenta no encontrada");
    }
}
