package com.esports.resultservice.service;

import com.esports.resultservice.client.MatchClient;
import com.esports.resultservice.model.Resultado;
import com.esports.resultservice.model.dto.ResultadoRequestDTO;
import com.esports.resultservice.repository.ResultadoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ResultadoService - pruebas unitarias")
class ResultadoServiceTest {

    @Mock
    private ResultadoRepository resultadoRepository;

    @Mock
    private MatchClient matchClient;

    @InjectMocks
    private ResultadoService resultadoService;

    private ResultadoRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        requestDTO = new ResultadoRequestDTO();
        requestDTO.setPartidaId(1L);
        requestDTO.setGanadorId(10L);
        requestDTO.setPuntajeA(3);
        requestDTO.setPuntajeB(1);
        requestDTO.setEvidenciaUrl("https://evidencia.com/foto.png");
    }

    @Test
    @DisplayName("crearResultado() debe guardar cuando la partida existe y no tiene resultado previo")
    void crearResultado_conDatosValidos_creaElResultado() {
        when(matchClient.verificarPartidaExiste(1L)).thenReturn(true);
        when(resultadoRepository.findByPartidaId(1L)).thenReturn(Collections.emptyList());
        when(resultadoRepository.save(any(Resultado.class))).thenAnswer(inv -> {
            Resultado r = inv.getArgument(0);
            r.setId(1L);
            return r;
        });

        Resultado resultado = resultadoService.crearResultado(requestDTO);

        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getPuntajeA()).isEqualTo(3);
    }

    @Test
    @DisplayName("crearResultado() debe fallar si la partida no existe en match-service")
    void crearResultado_conPartidaInexistente_lanzaExcepcion() {
        when(matchClient.verificarPartidaExiste(1L)).thenReturn(false);

        assertThatThrownBy(() -> resultadoService.crearResultado(requestDTO))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("no existe");

        verify(resultadoRepository, never()).save(any());
    }

    @Test
    @DisplayName("crearResultado() debe fallar si ya existe un resultado para esa partida")
    void crearResultado_conResultadoDuplicado_lanzaExcepcion() {
        when(matchClient.verificarPartidaExiste(1L)).thenReturn(true);
        when(resultadoRepository.findByPartidaId(1L)).thenReturn(List.of(new Resultado()));

        assertThatThrownBy(() -> resultadoService.crearResultado(requestDTO))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("Ya existe un resultado");
    }

    @Test
    @DisplayName("actualizarResultado() no permite modificar un resultado ya VALIDADO")
    void actualizarResultado_conResultadoValidado_lanzaExcepcion() {
        Resultado existente = new Resultado();
        existente.setId(1L);
        existente.setEstadoValidacion("VALIDADO");

        when(resultadoRepository.findById(1L)).thenReturn(Optional.of(existente));

        assertThatThrownBy(() -> resultadoService.actualizarResultado(1L, requestDTO))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("no puede ser alterado");
    }

    @Test
    @DisplayName("validarResultado() solo permite validar resultados en estado PENDIENTE")
    void validarResultado_conEstadoNoPendiente_lanzaExcepcion() {
        Resultado existente = new Resultado();
        existente.setId(1L);
        existente.setEstadoValidacion("ANULADO");

        when(resultadoRepository.findById(1L)).thenReturn(Optional.of(existente));

        assertThatThrownBy(() -> resultadoService.validarResultado(1L))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("estado PENDIENTE");
    }

    @Test
    @DisplayName("validarResultado() cambia el estado a VALIDADO cuando esta PENDIENTE")
    void validarResultado_conEstadoPendiente_loValida() {
        Resultado existente = new Resultado();
        existente.setId(1L);
        existente.setEstadoValidacion("PENDIENTE");

        when(resultadoRepository.findById(1L)).thenReturn(Optional.of(existente));
        when(resultadoRepository.save(any(Resultado.class))).thenAnswer(inv -> inv.getArgument(0));

        Resultado resultado = resultadoService.validarResultado(1L);

        assertThat(resultado.getEstadoValidacion()).isEqualTo("VALIDADO");
    }

    @Test
    @DisplayName("anularResultado() debe fallar si el resultado ya esta anulado")
    void anularResultado_conResultadoYaAnulado_lanzaExcepcion() {
        Resultado existente = new Resultado();
        existente.setId(1L);
        existente.setEstadoValidacion("ANULADO");

        when(resultadoRepository.findById(1L)).thenReturn(Optional.of(existente));

        assertThatThrownBy(() -> resultadoService.anularResultado(1L, "duplicado"))
                .isInstanceOf(IllegalStateException.class)
                .hasMessageContaining("ya está anulado");
    }

    @Test
    @DisplayName("anularResultado() debe guardar el estado ANULADO con su justificacion")
    void anularResultado_conResultadoPendiente_loAnula() {
        Resultado existente = new Resultado();
        existente.setId(1L);
        existente.setEstadoValidacion("PENDIENTE");

        when(resultadoRepository.findById(1L)).thenReturn(Optional.of(existente));
        when(resultadoRepository.save(any(Resultado.class))).thenAnswer(inv -> inv.getArgument(0));

        Resultado resultado = resultadoService.anularResultado(1L, "Evidencia falsa");

        assertThat(resultado.getEstadoValidacion()).isEqualTo("ANULADO");
        assertThat(resultado.getJustificacionAnulacion()).isEqualTo("Evidencia falsa");
    }

    @Test
    @DisplayName("buscarPorId() debe lanzar excepcion si el resultado no existe")
    void buscarPorId_conIdInexistente_lanzaExcepcion() {
        when(resultadoRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> resultadoService.buscarPorId(404L))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessageContaining("no encontrado");
    }
}
