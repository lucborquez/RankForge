package com.esports.resultservice.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

// Cliente REST hacia match-service usando WebClient (no bloqueante), con timeout.
@Component
public class MatchClient {

    private static final Logger log = LoggerFactory.getLogger(MatchClient.class);
    private static final Duration TIMEOUT = Duration.ofSeconds(3);

    private final WebClient webClient;

    public MatchClient(@Value("${match.service.url}") String matchServiceUrl) {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(TIMEOUT);

        this.webClient = WebClient.builder()
                .baseUrl(matchServiceUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    // Usado por ResultadoService para verificar si la partida existe antes de registrar un resultado
    public boolean verificarPartidaExiste(Long partidaId) {
        try {
            webClient.get()
                    .uri("/api/partidas/{id}", partidaId)
                    .retrieve()
                    .toBodilessEntity()
                    .block(TIMEOUT);
            return true;
        } catch (WebClientResponseException.NotFound e) {
            log.warn("Partida {} no existe en match-service", partidaId);
            return false;
        } catch (Exception e) {
            log.error("Error consultando match-service para partidaId {}: {}",
                    partidaId, e.getMessage());
            return false;
        }
    }
}
