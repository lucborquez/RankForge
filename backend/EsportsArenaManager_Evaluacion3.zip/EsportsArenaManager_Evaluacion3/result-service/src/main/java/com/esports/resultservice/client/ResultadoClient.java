package com.esports.resultservice.client;

import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;
import java.time.LocalDateTime;

// Cliente REST interno, usado para exponer/consumir datos de resultado ya existentes.
// Migrado de RestTemplate a WebClient (no bloqueante), con timeout explícito.
@Component
public class ResultadoClient {

    private static final Logger log = LoggerFactory.getLogger(ResultadoClient.class);
    private static final Duration TIMEOUT = Duration.ofSeconds(3);

    private final WebClient webClient;

    public ResultadoClient(@Value("${result.service.url:http://localhost:8088}") String resultServiceUrl) {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(TIMEOUT);

        this.webClient = WebClient.builder()
                .baseUrl(resultServiceUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    // Busca un resultado consumiendo el endpoint GET correspondiente
    public ResultadoDTO obtenerResultadoPorId(Long resultadoId) {
        try {
            return webClient.get()
                    .uri("/api/resultados/{id}", resultadoId)
                    .retrieve()
                    .bodyToMono(ResultadoDTO.class)
                    .block(TIMEOUT);
        } catch (WebClientResponseException.NotFound e) {
            log.warn("Resultado {} no existe", resultadoId);
            return null;
        } catch (Exception e) {
            log.error("Error consultando result-service para resultadoId {}: {}",
                    resultadoId, e.getMessage());
            return null;
        }
    }

    // DTO espejo interno para manejar los datos del resultado de forma limpia
    @Data
    public static class ResultadoDTO {
        private Long id;
        private Long partidaId;
        private Long ganadorId;
        private Integer puntajeA;
        private Integer puntajeB;
        private String estadoValidacion;
        private String evidenciaUrl;
        private String justificacionAnulacion;
        private LocalDateTime fechaRegistro;
    }
}
