# Diagrama del ecosistema de microservicios — eSports Arena Manager

Este documento cubre la evidencia mínima de entrega solicitada en el caso semestral:
diagrama del ecosistema y modelo relacional de las bases de datos principales.
Los diagramas están en formato [Mermaid](https://mermaid.js.org/), que GitHub renderiza
automáticamente al ver este archivo en el repositorio (no requiere abrir ninguna
herramienta externa).

## 1. Arquitectura general

```mermaid
graph TD
    Cliente[Cliente / Postman / Frontend] --> GW[API Gateway :8080]
    GW --> AUTH[auth-service :8083]
    GW --> USER[user-service :8082]
    GW --> GAME[game-service :8081]
    GW --> TEAM[team-service :8084]
    GW --> TOUR[tournament-service :8085]
    GW --> REG[registration-service :8086]
    GW --> MATCH[match-service :8087]
    GW --> RES[result-service :8088]
    GW --> RANK[ranking-service :8089]
    GW --> SANC[sanction-service :8090]

    AUTH -. registra .-> EUREKA[Eureka Server :8761]
    USER -. registra .-> EUREKA
    GAME -. registra .-> EUREKA
    TEAM -. registra .-> EUREKA
    TOUR -. registra .-> EUREKA
    REG -. registra .-> EUREKA
    MATCH -. registra .-> EUREKA
    RES -. registra .-> EUREKA
    RANK -. registra .-> EUREKA
    SANC -. registra .-> EUREKA
    GW -. resuelve rutas via lb:// .-> EUREKA
```

## 2. Comunicación real entre microservicios (WebClient)

Cada flecha representa una llamada REST síncrona hecha con `WebClient` (con timeout
de 3s y manejo de errores remotos), según lo exige la pauta de evaluación.

```mermaid
graph LR
    TEAM -->|"¿usuario activo?"| USER
    TOUR -->|"¿juego existe?"| GAME
    REG -->|"info del torneo"| TOUR
    REG -->|"¿sanción activa?"| SANC
    MATCH -->|"¿torneo existe?"| TOUR
    MATCH -->|"¿participante inscrito?"| REG
    RES -->|"¿partida existe?"| MATCH
```

## 3. Flujo integrador mínimo (según caso semestral, sección 8)

```mermaid
sequenceDiagram
    participant Admin
    participant Game as game-service
    participant Tour as tournament-service
    participant Team as team-service
    participant Reg as registration-service
    participant Match as match-service
    participant Res as result-service
    participant Rank as ranking-service

    Admin->>Game: POST /api/juegos
    Admin->>Tour: POST /api/torneos (juegoId)
    Admin->>Tour: PATCH /api/torneos/{id}/estado = ABIERTO
    Team->>Team: POST /api/equipos
    Reg->>Tour: GET /api/torneos/{id} (valida estado, cupo, fecha cierre)
    Reg->>Reg: POST /api/inscripciones
    Match->>Reg: GET /api/inscripciones/torneo/{id} (valida participante)
    Match->>Match: POST /api/partidas
    Res->>Match: GET /api/partidas/{id} (valida existencia)
    Res->>Res: POST /api/resultados + PATCH /validar
    Rank->>Rank: POST /api/rankings (con resultado validado)
```

## 4. Modelo relacional por microservicio (resumen)

Cada microservicio mantiene **su propia base de datos**, sin tablas compartidas
(cumpliendo el requisito de independencia de datos).

```mermaid
erDiagram
    CUENTA_ACCESO {
        Long id PK
        String email
        String passwordHash
        String rol
        Boolean estado
        LocalDate fechaCreacion
    }
    USUARIO {
        Long id PK
        String nombre
        String apodo
        String email
        String rol
        Boolean estado
        LocalDate fechaRegistro
    }
    JUEGO {
        Long id PK
        String nombre
        String genero
        String modalidad
        Integer jugadoresPorEquipo
        Boolean estado
    }
    EQUIPO {
        Long id PK
        String nombre
        Long capitanId
        Long juegoPrincipalId
        String estado
    }
    MIEMBRO_EQUIPO {
        Long id PK
        Long equipoId FK
        Long usuarioId
        String rolDentroEquipo
    }
    TORNEO {
        Long id PK
        String nombre
        Long juegoId
        String fechaInicio
        String fechaFin
        String fechaCierreInscripcion
        Integer cupoMaximo
        String estado
        String modalidad
    }
    INSCRIPCION {
        Long id PK
        Long torneoId
        Long equipoId
        Long jugadorId
        String tipoParticipante
        String estado
        LocalDate fechaInscripcion
    }
    PARTIDA {
        Long id PK
        Long torneoId
        Long participanteAId
        Long participanteBId
        String ronda
        String fechaHora
        String estado
    }
    RESULTADO {
        Long id PK
        Long partidaId
        Long ganadorId
        Integer puntajeA
        Integer puntajeB
        String estadoValidacion
        String evidenciaUrl
    }
    RANKING {
        Long id PK
        Long torneoId
        Long participanteId
        Integer puntos
        Integer victorias
        Integer derrotas
        Integer diferencia
        Integer posicion
    }
    SANCION {
        Long id PK
        Long usuarioId
        Long equipoId
        String motivo
        String severidad
        LocalDate fechaInicio
        LocalDate fechaFin
        String estado
    }

    EQUIPO ||--o{ MIEMBRO_EQUIPO : contiene
```

> Nota: las relaciones entre entidades de distintos microservicios (por ejemplo
> `Inscripcion.jugadorId -> Usuario.id`) son **lógicas, no FKs de base de datos**,
> porque cada microservicio tiene su propio esquema y esas referencias se validan
> vía llamadas REST (WebClient), no vía integridad referencial de SQL.
