# eSports Arena Manager

eSports Arena Manager es una plataforma backend orientada a la administración de torneos competitivos de videojuegos.
El sistema fue desarrollado bajo una arquitectura de microservicios utilizando Spring Boot, permitiendo separar responsabilidades y mantener una solución modular, escalable y mantenible.

El objetivo principal del proyecto es gestionar torneos de eSports mediante servicios independientes encargados de usuarios, equipos, partidas, resultados, rankings, sanciones y procesos relacionados al flujo competitivo.

La solución fue diseñada aplicando buenas prácticas de desarrollo backend, persistencia relacional, validaciones, manejo de excepciones, pruebas unitarias, documentación con Swagger/OpenAPI, descubrimiento de servicios con Eureka, un API Gateway centralizado y despliegue con Docker.

## Integrantes
Lucas Borquez
Jhon Olivares

## Arquitectura general del sistema
La solución fue diseñada bajo una arquitectura de microservicios independientes, donde cada servicio posee:

1. Responsabilidad específica
2. Base de datos independiente
3. CRUD propio
4. Endpoints REST documentados con Swagger/OpenAPI
5. Reglas de negocio
6. Validaciones
7. Manejo de excepciones
8. Pruebas unitarias (JUnit 5 + Mockito)
9. Comunicación REST con otros microservicios
10. Registro automático en Eureka (descubrimiento de servicios)

Todo el tráfico externo entra a través de un **API Gateway** (puerto 8080), que enruta cada petición al microservicio correspondiente usando el nombre registrado en **Eureka** (puerto 8761), en vez de direcciones fijas.

## Microservicios

| Servicio | Puerto | Base de datos | Responsabilidad |
|---|---|---|---|
| eureka-server | 8761 | — | Registro y descubrimiento de servicios |
| api-gateway | 8080 | — | Punto de entrada único, enrutamiento |
| auth-service | 8083 | db_auth_service | Login, registro y roles (JWT) |
| user-service | 8082 | db_user_service | Identidades, roles y estados de cuenta |
| game-service | 8081 | db_game_service | Catálogo de videojuegos y modalidades |
| team-service | 8084 | db_team_service | Equipos, membresías y capitanes |
| tournament-service | 8085 | db_tournament_service | Motor de torneos y control de estados |
| registration-service | 8086 | db_registration_service | Inscripciones con validación de sanciones y cupos |
| match-service | 8087 | db_match_service | Programación de partidas y enfrentamientos |
| result-service | 8088 | db_esports_resultados | Registro y validación de resultados |
| ranking-service | 8089 | db_ranking_service | Cálculo de posiciones y estadísticas |
| sanction-service | 8090 | db_sanction_service | Sanciones y sistema de Fair Play |

## Rutas del API Gateway

Todas las peticiones externas se hacen contra `http://localhost:8080` (o el dominio remoto si está desplegado), nunca directo a los puertos de cada microservicio:

| Ruta del Gateway | Microservicio destino |
|---|---|
| `/api/auth/**` | auth-service |
| `/api/usuarios/**` | user-service |
| `/api/juegos/**` | game-service |
| `/api/equipos/**` | team-service |
| `/api/torneos/**` | tournament-service |
| `/api/inscripciones/**` | registration-service |
| `/api/partidas/**` | match-service |
| `/api/resultados/**` | result-service |
| `/api/rankings/**` | ranking-service |
| `/api/sanciones/**` | sanction-service |

Ejemplo: para listar usuarios se llama a `GET http://localhost:8080/api/usuarios`, **no** a `GET http://localhost:8082/api/usuarios`.

## Documentación Swagger / OpenAPI

Cada microservicio expone su propia documentación interactiva (con el servicio corriendo):

| Servicio | Swagger UI |
|---|---|
| auth-service | http://localhost:8083/swagger-ui.html |
| user-service | http://localhost:8082/swagger-ui.html |
| game-service | http://localhost:8081/swagger-ui.html |
| team-service | http://localhost:8084/swagger-ui.html |
| tournament-service | http://localhost:8085/swagger-ui.html |
| registration-service | http://localhost:8086/swagger-ui.html |
| match-service | http://localhost:8087/swagger-ui.html |
| result-service | http://localhost:8088/swagger-ui.html |
| ranking-service | http://localhost:8089/swagger-ui.html |
| sanction-service | http://localhost:8090/swagger-ui.html |

(Si se despliega en Railway/Render/Docker remoto, reemplazar `localhost:<puerto>` por el dominio público de cada servicio.)

## Tecnologías usadas

### Backend
1. Java 26
2. Spring Boot 4.0.6
3. Spring Cloud 2025.1.1 (Eureka Server/Client, Gateway WebMVC, LoadBalancer)
4. Spring Data JPA + Hibernate
5. Maven (con Maven Wrapper)
6. Bean Validation (Jakarta Validation)
7. springdoc-openapi (Swagger UI)
8. JUnit 5 + Mockito + AssertJ (pruebas unitarias)
9. Docker / Docker Compose

### Base de datos
Para la persistencia se utilizó:
1. MySQL 8
2. Laragon (entorno local de desarrollo)
3. HeidiSQL (administración visual de las bases de datos)

Laragon fue utilizado como entorno local de desarrollo debido a su facilidad de configuración, integración rápida con MySQL y administración eficiente de servicios locales.
HeidiSQL fue utilizado para administrar las bases de datos, permitiendo visualizar tablas, ejecutar consultas SQL y verificar relaciones de manera más profesional y práctica durante el desarrollo.

## Flujo principal
1. Crear videojuego → game-service
2. Crear usuarios → user-service
3. Crear equipo → team-service (requiere usuario activo y juego)
4. Crear torneo → tournament-service (requiere juego)
5. Abrir torneo → tournament-service `PATCH /api/torneos/{id}/estado` con body `{ "estado": "ABIERTO" }`
6. Inscribir equipo → registration-service (valida sanciones y cupos)
7. Crear partida → match-service (valida inscripciones)
8. Registrar resultado → result-service
9. Consultar ranking → ranking-service
10. Registrar sanción → sanction-service (bloquea futuras inscripciones si la sanción está activa)

## Capa de Modelo y Anotaciones
Se utiliza el ecosistema de Spring Data JPA y Lombok para maximizar la productividad y garantizar la integridad de los datos:

- **Lombok**: `@Data`, `@AllArgsConstructor`, `@NoArgsConstructor`, `@Builder` y `@Getter`/`@Setter` para reducir el código redundante.
- **JPA/Hibernate**: `@Entity`, `@Table`, `@Id`, `@GeneratedValue(strategy = GenerationType.IDENTITY)` y `@Column` para el mapeo relacional preciso.
- **Jakarta Validation**: `@NotBlank`, `@NotNull`, `@Positive` y `@Size` en los DTOs para la validación de entrada de datos.

## Patrón Arquitectónico CSR
Todos los microservicios fueron estructurados utilizando el patrón:

- **Controller** → manejo de endpoints REST
- **Service** → lógica de negocio
- **Repository** → acceso a datos
- **Model** → entidades JPA
- **DTO** → validaciones y transferencia de datos

---

## Instrucciones de ejecución LOCAL (sin Docker)

Requisitos: JDK 26, Maven (o usar el `mvnw` incluido), MySQL corriendo en `localhost:3306` (ej. vía Laragon) con usuario `root` sin contraseña.

Orden de arranque (importante, respetar este orden):

1. **eureka-server** (puerto 8761) — esperar a que cargue completo.
2. Los **10 microservicios** (auth, user, game, team, tournament, registration, match, result, ranking, sanction) — en cualquier orden entre ellos.
3. **api-gateway** (puerto 8080) — al final, porque también es cliente Eureka.

Desde IntelliJ: abrir cada módulo y correr su clase `*Application.java`. Por defecto cada servicio usa el perfil `dev` (definido en su `application.yml`), que apunta a MySQL local.

Verificar que todo esté registrado: abrir **http://localhost:8761** y confirmar que aparecen los 10 microservicios + el gateway con estado `UP`.

Probar a través del gateway, por ejemplo:
```
GET http://localhost:8080/api/usuarios
GET http://localhost:8080/api/juegos
```

## Instrucciones de ejecución REMOTA / Docker

Requisitos: Docker y Docker Compose instalados.

Desde la raíz del proyecto (donde está `docker-compose.yml`):

```bash
docker compose up --build
```

Esto levanta automáticamente, en este orden, mediante `depends_on`:
1. `mysql` (con las 10 bases de datos creadas por `init.sql`)
2. `eureka-server`
3. Los 10 microservicios (cada uno con el perfil `prod`, que lee la conexión a la base de datos desde variables de entorno en vez de `localhost`)
4. `api-gateway`

Una vez levantado:
- Panel de Eureka: http://localhost:8761
- Punto de entrada único: http://localhost:8080
- Swagger de cada servicio: en su puerto individual (ver tabla más arriba), igual que en local.

Para apagar todo y borrar los contenedores:
```bash
docker compose down
```

> Nota: los `Dockerfile` de este proyecto usan la imagen `eclipse-temurin:26`, porque el código compila con `java.version=26`. Si tu Docker local no encuentra esa imagen, cambia el tag a `21` en el `Dockerfile` del módulo afectado y ajusta `java.version` a `21` en su `pom.xml` (deben coincidir).

## Cómo correr las pruebas unitarias

Cada microservicio tiene sus pruebas unitarias (JUnit 5 + Mockito) en `src/test/java`, sobre la capa de Service (reglas de negocio), simulando los repositorios y los clientes a otros microservicios.

Desde la carpeta de cualquier servicio:
```bash
./mvnw test
```

O desde la raíz del proyecto, para correr las pruebas de todos los módulos (gracias al `pom.xml` raíz tipo aggregator):
```bash
./mvnw test -pl auth-service,user-service,game-service,team-service,tournament-service,registration-service,match-service,result-service,ranking-service,sanction-service
```

## Evidencias mínimas de entrega

- **Repositorio GitHub**: organizado por microservicios (esta carpeta raíz).
- **README.md**: este archivo (contexto, integrantes, instrucciones de ejecución, puertos y endpoints).
- **Colección Postman**: [`postman/eSports-Arena-Manager.postman_collection.json`](./postman/eSports-Arena-Manager.postman_collection.json), con pruebas REST de los 10 microservicios siguiendo el flujo integrador (juego → torneo → equipo → inscripción → partida → resultado → ranking → sanción), todas a través del API Gateway.
- **Diagrama del ecosistema y modelo relacional**: [`diagramas/arquitectura.md`](./diagramas/arquitectura.md) (formato Mermaid, se visualiza directamente en GitHub).
- **Evidencia de tareas en Trello**: *(pendiente — agregar aquí el link público del tablero antes de la entrega; la pauta exige evidenciar roles y avance del equipo)*.
- **Swagger/OpenAPI, pruebas unitarias, API Gateway, YAML y despliegue**: cubiertos en las secciones anteriores de este README.

## Cambios y correcciones aplicadas respecto a la versión anterior

Esta versión corrige los siguientes puntos detectados al revisar el proyecto contra la
pauta del EFT y el caso semestral:

1. **Comunicación entre microservicios migrada de `RestTemplate` a `WebClient`**
   (team-service, tournament-service, registration-service, match-service, result-service).
   La pauta exige explícitamente `WebClient` o `Feign Client`; `RestTemplate` no cumplía
   el requisito y además se instanciaba manualmente sin timeout, lo que podía dejar un
   microservicio colgado indefinidamente si otro no respondía. Ahora cada cliente usa
   `WebClient` con timeout de 3 segundos y distingue errores 404 de errores de conexión.
2. **`user-service` no tenía `@RestControllerAdvice`** en su `GlobalExceptionHandler`,
   por lo que **nunca capturaba ninguna excepción** (quedaba como una clase suelta). Se agregó
   la anotación.
3. **`auth-service` tenía los manejadores de excepción cruzados**: el método que debía
   capturar errores de validación (`MethodArgumentNotValidException`) estaba anotado
   para capturar `Exception` genérica, y viceversa. Esto rompía el manejo de errores en
   tiempo de ejecución. Se corrigió la asociación anotación/parámetro.
4. **Faltaba la regla de negocio "no inscribir fuera de plazo"** en `registration-service`,
   exigida explícitamente en el caso semestral. Se agregó la validación contra
   `fechaCierreInscripcion` del torneo, junto con su prueba unitaria.
5. **`game-service` tenía la URL de Eureka hardcodeada** (sin permitir override por variable
   de entorno), a diferencia de todos los demás servicios. Se alineó con el mismo patrón
   `${EUREKA_SERVER_URL:...}` usado en el resto, necesario para que funcione igual en Docker/Railway.
6. **El valor por defecto de `result.service.url` apuntaba al puerto 8083** (que es el de
   `auth-service`) en lugar del puerto real de `result-service` (8088). Corregido.
7. Se agregaron los artefactos de evidencia mínima que faltaban: colección Postman y
   diagrama del ecosistema/modelo relacional (ver sección anterior).
8. **`jacoco-maven-plugin` faltaba en 8 de los 10 microservicios** (solo `game-service` y
   `ranking-service` lo tenían). Sin JaCoCo no hay forma de mostrar el % de cobertura
   exigido (IE 3.1.1: "cobertura mínima del 80% demostrable") durante la defensa. Se agregó
   el mismo plugin a los 10 `pom.xml`. Después de correr `./mvnw test` en cualquier servicio,
   el reporte queda en `target/site/jacoco/index.html`.

### Puntos que ya estaban correctos (no se tocaron)
- Estructura CSR (Controller–Service–Repository/Model) en los 10 microservicios.
- Persistencia real con JPA + Hibernate, un esquema de base de datos por microservicio.
- Bean Validation en los DTOs de entrada, con mensajes de error claros.
- `@RestControllerAdvice` + excepciones personalizadas en el resto de los servicios.
- Logs estructurados con SLF4J en las capas de servicio.
- Documentación Swagger/OpenAPI habilitada en los 10 microservicios.
- Configuración YAML con perfiles `dev`/`prod` separados en todos los servicios.
- Registro en Eureka y enrutamiento centralizado vía API Gateway.
- Pruebas unitarias con JUnit 5 + Mockito + AssertJ, con mocks de repositorios y clientes.
- Dockerfiles y `docker-compose.yml` para despliegue local containerizado.
- Cumplimiento del mínimo de 10 microservicios exigido por la pauta.

## Conclusión
El proyecto eSports Arena Manager permitió aplicar conocimientos relacionados con arquitectura distribuida basada en microservicios, persistencia relacional, desarrollo REST, validaciones, manejo de excepciones, pruebas unitarias, documentación de APIs, descubrimiento de servicios, un API Gateway centralizado, comunicación entre servicios y despliegue con contenedores.
