package com.esports.ranking_service.service;

import com.esports.ranking_service.dto.RankingRequestDTO;
import com.esports.ranking_service.dto.RankingResponseDTO;
import com.esports.ranking_service.exception.RankingNotFoundException;
import com.esports.ranking_service.model.Ranking;
import com.esports.ranking_service.repository.RankingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("RankingService - pruebas unitarias")
class RankingServiceTest {

    @Mock
    private RankingRepository rankingRepository;

    @InjectMocks
    private RankingService rankingService;

    private Ranking rankingExistente;

    @BeforeEach
    void setUp() {
        rankingExistente = new Ranking();
        rankingExistente.setId(1L);
        rankingExistente.setTorneoId(1L);
        rankingExistente.setParticipanteId(10L);
        rankingExistente.setPuntos(15);
        rankingExistente.setVictorias(5);
        rankingExistente.setDerrotas(1);
        rankingExistente.setDiferencia(20);
        rankingExistente.setPosicion(1);
    }

    @Test
    @DisplayName("crear() debe fallar si ya existe un ranking para ese participante en ese torneo")
    void crear_conRankingDuplicado_lanzaExcepcion() {
        RankingRequestDTO dto = new RankingRequestDTO();
        dto.setTorneoId(1L);
        dto.setParticipanteId(10L);

        when(rankingRepository.existsByTorneoIdAndParticipanteId(1L, 10L)).thenReturn(true);

        assertThatThrownBy(() -> rankingService.crear(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Ya existe un ranking");

        verify(rankingRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe usar 0 como valor por defecto cuando puntos/victorias/derrotas vienen nulos")
    void crear_sinEstadisticas_usaCerosPorDefecto() {
        RankingRequestDTO dto = new RankingRequestDTO();
        dto.setTorneoId(1L);
        dto.setParticipanteId(20L);
        // puntos, victorias, derrotas, diferencia, posicion quedan null a proposito

        when(rankingRepository.existsByTorneoIdAndParticipanteId(1L, 20L)).thenReturn(false);
        when(rankingRepository.save(any(Ranking.class))).thenAnswer(inv -> inv.getArgument(0));

        RankingResponseDTO resultado = rankingService.crear(dto);

        assertThat(resultado.getPuntos()).isZero();
        assertThat(resultado.getVictorias()).isZero();
        assertThat(resultado.getDerrotas()).isZero();
    }

    @Test
    @DisplayName("actualizar() debe mantener el valor anterior cuando el dto trae un campo nulo")
    void actualizar_conCampoNulo_mantieneElValorAnterior() {
        RankingRequestDTO dto = new RankingRequestDTO();
        dto.setPuntos(30); // solo actualiza puntos, el resto viene null

        when(rankingRepository.findById(1L)).thenReturn(Optional.of(rankingExistente));
        when(rankingRepository.save(any(Ranking.class))).thenAnswer(inv -> inv.getArgument(0));

        RankingResponseDTO resultado = rankingService.actualizar(1L, dto);

        assertThat(resultado.getPuntos()).isEqualTo(30);
        // victorias no vino en el dto -> debe conservar el valor original (5)
        assertThat(resultado.getVictorias()).isEqualTo(5);
    }

    @Test
    @DisplayName("reiniciar() debe poner todas las estadisticas en cero")
    void reiniciar_conRankingExistente_reseteaTodo() {
        when(rankingRepository.findById(1L)).thenReturn(Optional.of(rankingExistente));
        when(rankingRepository.save(any(Ranking.class))).thenAnswer(inv -> inv.getArgument(0));

        RankingResponseDTO resultado = rankingService.reiniciar(1L);

        assertThat(resultado.getPuntos()).isZero();
        assertThat(resultado.getVictorias()).isZero();
        assertThat(resultado.getDerrotas()).isZero();
        assertThat(resultado.getPosicion()).isZero();
    }

    @Test
    @DisplayName("listarPorTorneo() debe devolver los rankings ordenados que entrega el repositorio")
    void listarPorTorneo_devuelveLaListaMapeada() {
        when(rankingRepository.findByTorneoIdOrderByPuntosDesc(1L)).thenReturn(List.of(rankingExistente));

        List<RankingResponseDTO> resultado = rankingService.listarPorTorneo(1L);

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getParticipanteId()).isEqualTo(10L);
    }

    @Test
    @DisplayName("buscarPorId() debe devolver el ranking mapeado cuando existe")
    void buscarPorId_conIdExistente_devuelveElRanking() {
        when(rankingRepository.findById(1L)).thenReturn(Optional.of(rankingExistente));

        RankingResponseDTO resultado = rankingService.buscarPorId(1L);

        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getParticipanteId()).isEqualTo(10L);
    }

    @Test
    @DisplayName("buscarPorId() debe lanzar RankingNotFoundException si no existe")
    void buscarPorId_conIdInexistente_lanzaNotFound() {
        when(rankingRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> rankingService.buscarPorId(404L))
                .isInstanceOf(RankingNotFoundException.class);
    }

    @Test
    @DisplayName("eliminar() debe llamar al delete del repositorio cuando el ranking existe")
    void eliminar_conRankingExistente_loElimina() {
        when(rankingRepository.findById(1L)).thenReturn(Optional.of(rankingExistente));

        rankingService.eliminar(1L);

        verify(rankingRepository).delete(rankingExistente);
    }

    @Test
    @DisplayName("listarTodos() debe devolver todos los rankings mapeados a DTO")
    void listarTodos_devuelveLaListaCompletaMapeada() {
        Ranking otro = new Ranking();
        otro.setId(2L);
        otro.setTorneoId(2L);
        otro.setParticipanteId(30L);
        otro.setPuntos(9);

        when(rankingRepository.findAll()).thenReturn(List.of(rankingExistente, otro));

        List<RankingResponseDTO> resultado = rankingService.listarTodos();

        assertThat(resultado).hasSize(2);
        assertThat(resultado.get(0).getId()).isEqualTo(1L);
        assertThat(resultado.get(1).getId()).isEqualTo(2L);
        verify(rankingRepository).findAll();
    }

    @Test
    @DisplayName("listarTodos() debe devolver lista vacia cuando no hay rankings")
    void listarTodos_sinRankings_devuelveListaVacia() {
        when(rankingRepository.findAll()).thenReturn(List.of());

        List<RankingResponseDTO> resultado = rankingService.listarTodos();

        assertThat(resultado).isEmpty();
    }

    @Test
    @DisplayName("buscarPorTorneoYParticipante() debe devolver el ranking cuando existe")
    void buscarPorTorneoYParticipante_conDatosExistentes_devuelveElRanking() {
        when(rankingRepository.findByTorneoIdAndParticipanteId(1L, 10L))
                .thenReturn(Optional.of(rankingExistente));

        RankingResponseDTO resultado = rankingService.buscarPorTorneoYParticipante(1L, 10L);

        assertThat(resultado.getTorneoId()).isEqualTo(1L);
        assertThat(resultado.getParticipanteId()).isEqualTo(10L);
    }

    @Test
    @DisplayName("buscarPorTorneoYParticipante() debe lanzar RankingNotFoundException si no existe")
    void buscarPorTorneoYParticipante_sinDatosExistentes_lanzaNotFound() {
        when(rankingRepository.findByTorneoIdAndParticipanteId(9L, 99L))
                .thenReturn(Optional.empty());

        assertThatThrownBy(() -> rankingService.buscarPorTorneoYParticipante(9L, 99L))
                .isInstanceOf(RankingNotFoundException.class);
    }

    @Test
    @DisplayName("listarPorParticipante() debe devolver el historial de rankings del participante")
    void listarPorParticipante_devuelveElHistorialMapeado() {
        when(rankingRepository.findByParticipanteId(10L)).thenReturn(List.of(rankingExistente));

        List<RankingResponseDTO> resultado = rankingService.listarPorParticipante(10L);

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getParticipanteId()).isEqualTo(10L);
        verify(rankingRepository).findByParticipanteId(10L);
    }

    @Test
    @DisplayName("listarPorParticipante() debe devolver lista vacia cuando el participante no tiene historial")
    void listarPorParticipante_sinHistorial_devuelveListaVacia() {
        when(rankingRepository.findByParticipanteId(999L)).thenReturn(List.of());

        List<RankingResponseDTO> resultado = rankingService.listarPorParticipante(999L);

        assertThat(resultado).isEmpty();
    }

    @Test
    @DisplayName("actualizar() debe lanzar RankingNotFoundException si el id no existe")
    void actualizar_conIdInexistente_lanzaNotFound() {
        RankingRequestDTO dto = new RankingRequestDTO();
        dto.setPuntos(10);

        when(rankingRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> rankingService.actualizar(404L, dto))
                .isInstanceOf(RankingNotFoundException.class);

        verify(rankingRepository, never()).save(any());
    }
}
