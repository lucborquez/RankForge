-- ═══════════════════════════════════════════════════
-- init.sql — Creación de bases de datos
-- Se ejecuta automáticamente al iniciar el contenedor MySQL
-- eSports Arena Manager
-- ═══════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS db_game_service;
CREATE DATABASE IF NOT EXISTS db_user_service;
CREATE DATABASE IF NOT EXISTS db_auth_service;
CREATE DATABASE IF NOT EXISTS db_team_service;
CREATE DATABASE IF NOT EXISTS db_tournament_service;
CREATE DATABASE IF NOT EXISTS db_registration_service;
CREATE DATABASE IF NOT EXISTS db_match_service;
CREATE DATABASE IF NOT EXISTS db_esports_resultados;
CREATE DATABASE IF NOT EXISTS db_ranking_service;
CREATE DATABASE IF NOT EXISTS db_sanction_service;

-- Permisos para el usuario root desde cualquier host (necesario en Docker)
GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' WITH GRANT OPTION;
FLUSH PRIVILEGES;
