package com.esports.registration_service.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

// Cliente REST hacia sanction-service usando WebClient (no bloqueante), con timeout.
@Component
public class SancionClient {

    private static final Logger log = LoggerFactory.getLogger(SancionClient.class);
    private static final Duration TIMEOUT = Duration.ofSeconds(3);

    private final WebClient webClient;

    public SancionClient(@Value("${sanction.service.url}") String sanctionServiceUrl) {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(TIMEOUT);

        this.webClient = WebClient.builder()
                .baseUrl(sanctionServiceUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    // Pregunta al sanction-service si el usuario tiene sanción activa
    public boolean tieneSancionActiva(Long usuarioId) {
        try {
            Boolean resultado = webClient.get()
                    .uri("/api/sanciones/usuario/{id}/activa", usuarioId)
                    .retrieve()
                    .bodyToMono(Boolean.class)
                    .block(TIMEOUT);
            return Boolean.TRUE.equals(resultado);
        } catch (WebClientResponseException.NotFound e) {
            log.warn("No hay registro de sanciones para el usuario {}", usuarioId);
            return false;
        } catch (Exception e) {
            log.error("Error consultando sanction-service para usuarioId {}: {}",
                    usuarioId, e.getMessage());
            return false;
        }
    }
}
