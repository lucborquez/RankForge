package com.esports.registration_service.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

// @Configuration: Spring lee esta clase al arrancar y registra el bean para springdoc.
@Configuration
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Registration Service API")
                        .version("1.0.0")
                        .description("Microservicio de gestion de inscripciones de jugadores y equipos a torneos de eSports Arena Manager.")
                        .contact(new Contact()
                                .name("eSports Arena Manager Team")));
    }
}
