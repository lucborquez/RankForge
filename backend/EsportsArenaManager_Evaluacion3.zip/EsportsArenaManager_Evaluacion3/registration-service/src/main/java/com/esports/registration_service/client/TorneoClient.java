package com.esports.registration_service.client;

import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

// Cliente REST hacia tournament-service usando WebClient (no bloqueante), con timeout.
@Component
public class TorneoClient {

    private static final Logger log = LoggerFactory.getLogger(TorneoClient.class);
    private static final Duration TIMEOUT = Duration.ofSeconds(3);

    private final WebClient webClient;

    public TorneoClient(@Value("${tournament.service.url}") String tournamentServiceUrl) {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(TIMEOUT);

        this.webClient = WebClient.builder()
                .baseUrl(tournamentServiceUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    // Verifica si el torneo existe y devuelve su información (estado, cupo, fecha de cierre)
    public TorneoInfoDTO obtenerTorneo(Long torneoId) {
        try {
            return webClient.get()
                    .uri("/api/torneos/{id}", torneoId)
                    .retrieve()
                    .bodyToMono(TorneoInfoDTO.class)
                    .block(TIMEOUT);
        } catch (WebClientResponseException.NotFound e) {
            log.warn("Torneo {} no existe en tournament-service", torneoId);
            return null;
        } catch (Exception e) {
            log.error("Error consultando tournament-service para torneoId {}: {}",
                    torneoId, e.getMessage());
            return null;
        }
    }

    // DTO interno para recibir solo lo que necesitamos del torneo
    @Data
    public static class TorneoInfoDTO {
        private Long id;
        private String estado;
        private Integer cupoMaximo;
        private String fechaCierreInscripcion;
    }
}
