package com.esports.registration_service.service;

import com.esports.registration_service.client.SancionClient;
import com.esports.registration_service.client.TorneoClient;
import com.esports.registration_service.dto.InscripcionRequestDTO;
import com.esports.registration_service.dto.InscripcionResponseDTO;
import com.esports.registration_service.exception.InscripcionNotFoundException;
import com.esports.registration_service.model.Inscripcion;
import com.esports.registration_service.repository.InscripcionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Pruebas unitarias de InscripcionService.
 * Se mockean DOS clientes a otros microservicios (TorneoClient y SancionClient),
 * para poder probar las reglas de negocio (cupo, sanciones, duplicados) sin
 * necesitar que tournament-service ni sanction-service esten corriendo.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("InscripcionService - pruebas unitarias")
class InscripcionServiceTest {

    @Mock
    private InscripcionRepository inscripcionRepository;

    @Mock
    private TorneoClient torneoClient;

    @Mock
    private SancionClient sancionClient;

    @InjectMocks
    private InscripcionService inscripcionService;

    private TorneoClient.TorneoInfoDTO torneoAbierto;

    @BeforeEach
    void setUp() {
        torneoAbierto = new TorneoClient.TorneoInfoDTO();
        torneoAbierto.setId(1L);
        torneoAbierto.setEstado("ABIERTO");
        torneoAbierto.setCupoMaximo(16);
    }

    private InscripcionRequestDTO inscripcionDeJugador(Long jugadorId) {
        InscripcionRequestDTO dto = new InscripcionRequestDTO();
        dto.setTorneoId(1L);
        dto.setJugadorId(jugadorId);
        dto.setTipoParticipante("JUGADOR");
        return dto;
    }

    @Test
    @DisplayName("crear() debe inscribir al jugador cuando el torneo esta abierto, hay cupo y no tiene sancion")
    void crear_conTodoValido_creaLaInscripcion() {
        InscripcionRequestDTO dto = inscripcionDeJugador(5L);

        when(torneoClient.obtenerTorneo(1L)).thenReturn(torneoAbierto);
        when(inscripcionRepository.countByTorneoIdAndEstadoNot(1L, "CANCELADA")).thenReturn(3L);
        when(sancionClient.tieneSancionActiva(5L)).thenReturn(false);
        when(inscripcionRepository.existsByTorneoIdAndJugadorId(1L, 5L)).thenReturn(false);
        when(inscripcionRepository.save(any(Inscripcion.class))).thenAnswer(inv -> {
            Inscripcion i = inv.getArgument(0);
            i.setId(100L);
            return i;
        });

        InscripcionResponseDTO resultado = inscripcionService.crear(dto);

        assertThat(resultado.getId()).isEqualTo(100L);
        assertThat(resultado.getEstado()).isEqualTo("PENDIENTE");
    }

    @Test
    @DisplayName("crear() debe fallar si el torneo no existe en tournament-service")
    void crear_conTorneoInexistente_lanzaExcepcion() {
        InscripcionRequestDTO dto = inscripcionDeJugador(5L);
        when(torneoClient.obtenerTorneo(1L)).thenReturn(null);

        assertThatThrownBy(() -> inscripcionService.crear(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("El torneo no existe");

        verify(inscripcionRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe fallar si el torneo no esta ABIERTO")
    void crear_conTorneoCerrado_lanzaExcepcion() {
        torneoAbierto.setEstado("CERRADO");
        InscripcionRequestDTO dto = inscripcionDeJugador(5L);
        when(torneoClient.obtenerTorneo(1L)).thenReturn(torneoAbierto);

        assertThatThrownBy(() -> inscripcionService.crear(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("no está abierto");
    }

    @Test
    @DisplayName("crear() debe fallar si el torneo ya alcanzo su cupo maximo")
    void crear_conCupoCompleto_lanzaExcepcion() {
        InscripcionRequestDTO dto = inscripcionDeJugador(5L);
        when(torneoClient.obtenerTorneo(1L)).thenReturn(torneoAbierto);
        // cupoMaximo es 16, y ya hay 16 inscritos activos -> cupo lleno
        when(inscripcionRepository.countByTorneoIdAndEstadoNot(1L, "CANCELADA")).thenReturn(16L);

        assertThatThrownBy(() -> inscripcionService.crear(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("cupo máximo");

        verify(inscripcionRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe fallar si la fecha de cierre de inscripcion ya paso")
    void crear_conPlazoVencido_lanzaExcepcion() {
        torneoAbierto.setFechaCierreInscripcion(java.time.LocalDate.now().minusDays(1).toString());
        InscripcionRequestDTO dto = inscripcionDeJugador(5L);
        when(torneoClient.obtenerTorneo(1L)).thenReturn(torneoAbierto);

        assertThatThrownBy(() -> inscripcionService.crear(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("plazo de inscripción");

        verify(inscripcionRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe fallar si el jugador tiene una sancion activa")
    void crear_conJugadorSancionado_lanzaExcepcion() {
        InscripcionRequestDTO dto = inscripcionDeJugador(5L);
        when(torneoClient.obtenerTorneo(1L)).thenReturn(torneoAbierto);
        when(inscripcionRepository.countByTorneoIdAndEstadoNot(1L, "CANCELADA")).thenReturn(0L);
        when(sancionClient.tieneSancionActiva(5L)).thenReturn(true);

        assertThatThrownBy(() -> inscripcionService.crear(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("sanción activa");

        verify(inscripcionRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe fallar si el jugador ya esta inscrito en el mismo torneo")
    void crear_conJugadorYaInscrito_lanzaExcepcion() {
        InscripcionRequestDTO dto = inscripcionDeJugador(5L);
        when(torneoClient.obtenerTorneo(1L)).thenReturn(torneoAbierto);
        when(inscripcionRepository.countByTorneoIdAndEstadoNot(1L, "CANCELADA")).thenReturn(0L);
        when(sancionClient.tieneSancionActiva(5L)).thenReturn(false);
        when(inscripcionRepository.existsByTorneoIdAndJugadorId(1L, 5L)).thenReturn(true);

        assertThatThrownBy(() -> inscripcionService.crear(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("ya está inscrito");
    }

    @Test
    @DisplayName("crear() debe fallar si falta el equipoId cuando el tipo es EQUIPO")
    void crear_conTipoEquipoSinEquipoId_lanzaExcepcion() {
        InscripcionRequestDTO dto = new InscripcionRequestDTO();
        dto.setTorneoId(1L);
        dto.setTipoParticipante("EQUIPO");
        // equipoId queda null a proposito

        assertThatThrownBy(() -> inscripcionService.crear(dto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("equipoId");

        // Esta validacion ocurre ANTES de consultar a tournament-service
        verify(torneoClient, never()).obtenerTorneo(any());
    }

    @Test
    @DisplayName("cancelar() debe cambiar el estado a CANCELADA")
    void cancelar_conInscripcionExistente_laMarcaCancelada() {
        Inscripcion inscripcion = new Inscripcion();
        inscripcion.setId(1L);
        inscripcion.setEstado("PENDIENTE");

        when(inscripcionRepository.findById(1L)).thenReturn(Optional.of(inscripcion));
        when(inscripcionRepository.save(any(Inscripcion.class))).thenAnswer(inv -> inv.getArgument(0));

        InscripcionResponseDTO resultado = inscripcionService.cancelar(1L);

        assertThat(resultado.getEstado()).isEqualTo("CANCELADA");
    }

    @Test
    @DisplayName("actualizarEstado() no permite modificar una inscripcion ya cancelada")
    void actualizarEstado_conInscripcionCancelada_lanzaExcepcion() {
        Inscripcion inscripcion = new Inscripcion();
        inscripcion.setId(1L);
        inscripcion.setEstado("CANCELADA");

        when(inscripcionRepository.findById(1L)).thenReturn(Optional.of(inscripcion));

        assertThatThrownBy(() -> inscripcionService.actualizarEstado(1L, "CONFIRMADA"))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("inscripcion cancelada");
    }

    @Test
    @DisplayName("buscarPorId() debe lanzar InscripcionNotFoundException si no existe")
    void buscarPorId_conIdInexistente_lanzaNotFound() {
        when(inscripcionRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> inscripcionService.buscarPorId(404L))
                .isInstanceOf(InscripcionNotFoundException.class);
    }
}
