package com.esports.game_service.service;

import com.esports.game_service.dto.JuegoRequestDTO;
import com.esports.game_service.dto.JuegoResponseDTO;
import com.esports.game_service.exception.JuegoNotFoundException;
import com.esports.game_service.model.Juego;
import com.esports.game_service.repository.JuegoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Pruebas unitarias para JuegoService.
 * Se mockea JuegoRepository para aislar la lógica de negocio.
 * Patrón: Given – When – Then
 */
@ExtendWith(MockitoExtension.class)
class JuegoServiceTest {

    @Mock
    private JuegoRepository juegoRepository;

    @InjectMocks
    private JuegoService juegoService;

    private JuegoRequestDTO requestDTO;
    private Juego juegoGuardado;

    // ──────────────────────────────────────────────
    // Fixtures compartidos
    // ──────────────────────────────────────────────
    @BeforeEach
    void setUp() {
        requestDTO = new JuegoRequestDTO();
        requestDTO.setNombre("League of Legends");
        requestDTO.setGenero("MOBA");
        requestDTO.setModalidad("5v5");
        requestDTO.setJugadoresPorEquipo(5);

        juegoGuardado = new Juego();
        juegoGuardado.setId(1L);
        juegoGuardado.setNombre("League of Legends");
        juegoGuardado.setGenero("MOBA");
        juegoGuardado.setModalidad("5v5");
        juegoGuardado.setJugadoresPorEquipo(5);
        juegoGuardado.setEstado(true);
    }

    // ──────────────────────────────────────────────
    // crear()
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("crear() - debe retornar DTO cuando el nombre no existe")
    void crear_debeRetornarDTO_cuandoNombreEsNuevo() {
        // Given
        when(juegoRepository.findByNombre("League of Legends")).thenReturn(Optional.empty());
        when(juegoRepository.save(any(Juego.class))).thenReturn(juegoGuardado);

        // When
        JuegoResponseDTO resultado = juegoService.crear(requestDTO);

        // Then
        assertThat(resultado).isNotNull();
        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getNombre()).isEqualTo("League of Legends");
        assertThat(resultado.getGenero()).isEqualTo("MOBA");
        assertThat(resultado.getModalidad()).isEqualTo("5v5");
        assertThat(resultado.getJugadoresPorEquipo()).isEqualTo(5);
        assertThat(resultado.isEstado()).isTrue();

        verify(juegoRepository).findByNombre("League of Legends");
        verify(juegoRepository).save(any(Juego.class));
    }

    @Test
    @DisplayName("crear() - debe lanzar excepción cuando el nombre ya existe")
    void crear_debeLanzarExcepcion_cuandoNombreYaExiste() {
        // Given
        when(juegoRepository.findByNombre("League of Legends")).thenReturn(Optional.of(juegoGuardado));

        // When / Then
        assertThatThrownBy(() -> juegoService.crear(requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("League of Legends");

        verify(juegoRepository, never()).save(any());
    }

    // ──────────────────────────────────────────────
    // buscarPorId()
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("buscarPorId() - debe retornar DTO cuando el juego existe")
    void buscarPorId_debeRetornarDTO_cuandoExiste() {
        // Given
        when(juegoRepository.findById(1L)).thenReturn(Optional.of(juegoGuardado));

        // When
        JuegoResponseDTO resultado = juegoService.buscarPorId(1L);

        // Then
        assertThat(resultado).isNotNull();
        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getNombre()).isEqualTo("League of Legends");

        verify(juegoRepository).findById(1L);
    }

    @Test
    @DisplayName("buscarPorId() - debe lanzar JuegoNotFoundException cuando no existe")
    void buscarPorId_debeLanzarNotFoundException_cuandoNoExiste() {
        // Given
        when(juegoRepository.findById(99L)).thenReturn(Optional.empty());

        // When / Then
        assertThatThrownBy(() -> juegoService.buscarPorId(99L))
                .isInstanceOf(JuegoNotFoundException.class)
                .hasMessageContaining("99");

        verify(juegoRepository).findById(99L);
    }

    // ──────────────────────────────────────────────
    // listarActivos()
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("listarActivos() - debe retornar lista de juegos activos")
    void listarActivos_debeRetornarListaDeActivos() {
        // Given
        Juego otroJuego = new Juego();
        otroJuego.setId(2L);
        otroJuego.setNombre("Valorant");
        otroJuego.setGenero("FPS");
        otroJuego.setModalidad("5v5");
        otroJuego.setJugadoresPorEquipo(5);
        otroJuego.setEstado(true);

        when(juegoRepository.findByEstadoTrue()).thenReturn(List.of(juegoGuardado, otroJuego));

        // When
        List<JuegoResponseDTO> resultado = juegoService.listarActivos();

        // Then
        assertThat(resultado).hasSize(2);
        assertThat(resultado).extracting(JuegoResponseDTO::getNombre)
                .containsExactlyInAnyOrder("League of Legends", "Valorant");

        verify(juegoRepository).findByEstadoTrue();
    }

    @Test
    @DisplayName("listarActivos() - debe retornar lista vacía cuando no hay juegos activos")
    void listarActivos_debeRetornarListaVacia_cuandoNoHayActivos() {
        // Given
        when(juegoRepository.findByEstadoTrue()).thenReturn(List.of());

        // When
        List<JuegoResponseDTO> resultado = juegoService.listarActivos();

        // Then
        assertThat(resultado).isEmpty();
        verify(juegoRepository).findByEstadoTrue();
    }

    // ──────────────────────────────────────────────
    // actualizar()
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("actualizar() - debe retornar DTO actualizado cuando el juego existe")
    void actualizar_debeRetornarDTOActualizado_cuandoExiste() {
        // Given
        JuegoRequestDTO updateDTO = new JuegoRequestDTO();
        updateDTO.setNombre("League of Legends Updated");
        updateDTO.setGenero("MOBA");
        updateDTO.setModalidad("5v5 Ranked");
        updateDTO.setJugadoresPorEquipo(5);

        Juego actualizado = new Juego();
        actualizado.setId(1L);
        actualizado.setNombre("League of Legends Updated");
        actualizado.setGenero("MOBA");
        actualizado.setModalidad("5v5 Ranked");
        actualizado.setJugadoresPorEquipo(5);
        actualizado.setEstado(true);

        when(juegoRepository.findById(1L)).thenReturn(Optional.of(juegoGuardado));
        when(juegoRepository.save(any(Juego.class))).thenReturn(actualizado);

        // When
        JuegoResponseDTO resultado = juegoService.actualizar(1L, updateDTO);

        // Then
        assertThat(resultado.getNombre()).isEqualTo("League of Legends Updated");
        assertThat(resultado.getModalidad()).isEqualTo("5v5 Ranked");

        verify(juegoRepository).findById(1L);
        verify(juegoRepository).save(any(Juego.class));
    }

    @Test
    @DisplayName("actualizar() - debe lanzar excepción cuando el juego no existe")
    void actualizar_debeLanzarExcepcion_cuandoNoExiste() {
        // Given
        when(juegoRepository.findById(99L)).thenReturn(Optional.empty());

        // When / Then
        assertThatThrownBy(() -> juegoService.actualizar(99L, requestDTO))
                .isInstanceOf(JuegoNotFoundException.class);

        verify(juegoRepository, never()).save(any());
    }

    // ──────────────────────────────────────────────
    // desactivar()
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("desactivar() - debe cambiar estado a false cuando el juego existe")
    void desactivar_debeCambiarEstadoFalse_cuandoExiste() {
        // Given
        when(juegoRepository.findById(1L)).thenReturn(Optional.of(juegoGuardado));
        when(juegoRepository.save(any(Juego.class))).thenReturn(juegoGuardado);

        // When
        juegoService.desactivar(1L);

        // Then
        assertThat(juegoGuardado.isEstado()).isFalse();
        verify(juegoRepository).findById(1L);
        verify(juegoRepository).save(juegoGuardado);
    }

    @Test
    @DisplayName("desactivar() - debe lanzar excepción cuando el juego no existe")
    void desactivar_debeLanzarExcepcion_cuandoNoExiste() {
        // Given
        when(juegoRepository.findById(55L)).thenReturn(Optional.empty());

        // When / Then
        assertThatThrownBy(() -> juegoService.desactivar(55L))
                .isInstanceOf(JuegoNotFoundException.class)
                .hasMessageContaining("55");

        verify(juegoRepository, never()).save(any());
    }
}
