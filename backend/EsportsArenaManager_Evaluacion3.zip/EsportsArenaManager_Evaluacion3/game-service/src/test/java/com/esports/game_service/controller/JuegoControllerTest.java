package com.esports.game_service.controller;

import com.esports.game_service.dto.JuegoRequestDTO;
import com.esports.game_service.dto.JuegoResponseDTO;
import com.esports.game_service.exception.JuegoNotFoundException;
import com.esports.game_service.service.JuegoService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Pruebas de integración de capa web para JuegoController.
 * Se mockea JuegoService para verificar comportamiento HTTP.
 * Patrón: Given – When – Then
 */
class JuegoControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private JuegoService juegoService;

    @Autowired
    private ObjectMapper objectMapper;

    private JuegoRequestDTO requestDTO;
    private JuegoResponseDTO responseDTO;

    @BeforeEach
    void setUp() {
        requestDTO = new JuegoRequestDTO();
        requestDTO.setNombre("Valorant");
        requestDTO.setGenero("FPS");
        requestDTO.setModalidad("5v5");
        requestDTO.setJugadoresPorEquipo(5);

        responseDTO = new JuegoResponseDTO();
        responseDTO.setId(1L);
        responseDTO.setNombre("Valorant");
        responseDTO.setGenero("FPS");
        responseDTO.setModalidad("5v5");
        responseDTO.setJugadoresPorEquipo(5);
        responseDTO.setEstado(true);
    }

    // ──────────────────────────────────────────────
    // POST /api/juegos
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("POST /api/juegos - debe retornar 201 y el DTO creado")
    void crear_debeRetornar201_cuandoDatosValidos() throws Exception {
        // Given
        when(juegoService.crear(any(JuegoRequestDTO.class))).thenReturn(responseDTO);

        // When / Then
        mockMvc.perform(post("/api/juegos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.nombre").value("Valorant"))
                .andExpect(jsonPath("$.genero").value("FPS"))
                .andExpect(jsonPath("$.estado").value(true));

        verify(juegoService).crear(any(JuegoRequestDTO.class));
    }

    @Test
    @DisplayName("POST /api/juegos - debe retornar 400 cuando el nombre está vacío")
    void crear_debeRetornar400_cuandoNombreEsBlanco() throws Exception {
        // Given
        requestDTO.setNombre("");

        // When / Then
        mockMvc.perform(post("/api/juegos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.nombre").exists());

        verify(juegoService, never()).crear(any());
    }

    @Test
    @DisplayName("POST /api/juegos - debe retornar 400 cuando jugadoresPorEquipo es negativo")
    void crear_debeRetornar400_cuandoJugadoresNegativo() throws Exception {
        // Given
        requestDTO.setJugadoresPorEquipo(-1);

        // When / Then
        mockMvc.perform(post("/api/juegos")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.jugadoresPorEquipo").exists());

        verify(juegoService, never()).crear(any());
    }

    // ──────────────────────────────────────────────
    // GET /api/juegos/{id}
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("GET /api/juegos/{id} - debe retornar 200 y el DTO cuando existe")
    void buscar_debeRetornar200_cuandoExiste() throws Exception {
        // Given
        when(juegoService.buscarPorId(1L)).thenReturn(responseDTO);

        // When / Then
        mockMvc.perform(get("/api/juegos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(1L))
                .andExpect(jsonPath("$.nombre").value("Valorant"));

        verify(juegoService).buscarPorId(1L);
    }

    @Test
    @DisplayName("GET /api/juegos/{id} - debe retornar 404 cuando no existe")
    void buscar_debeRetornar404_cuandoNoExiste() throws Exception {
        // Given
        when(juegoService.buscarPorId(99L)).thenThrow(new JuegoNotFoundException(99L));

        // When / Then
        mockMvc.perform(get("/api/juegos/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.error").exists());

        verify(juegoService).buscarPorId(99L);
    }

    // ──────────────────────────────────────────────
    // PUT /api/juegos/{id}
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("PUT /api/juegos/{id} - debe retornar 200 y el DTO actualizado")
    void actualizar_debeRetornar200_cuandoExiste() throws Exception {
        // Given
        responseDTO.setModalidad("5v5 Ranked");
        when(juegoService.actualizar(eq(1L), any(JuegoRequestDTO.class))).thenReturn(responseDTO);

        // When / Then
        mockMvc.perform(put("/api/juegos/1")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.modalidad").value("5v5 Ranked"));

        verify(juegoService).actualizar(eq(1L), any(JuegoRequestDTO.class));
    }

    @Test
    @DisplayName("PUT /api/juegos/{id} - debe retornar 404 cuando no existe")
    void actualizar_debeRetornar404_cuandoNoExiste() throws Exception {
        // Given
        when(juegoService.actualizar(eq(99L), any())).thenThrow(new JuegoNotFoundException(99L));

        // When / Then
        mockMvc.perform(put("/api/juegos/99")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(requestDTO)))
                .andExpect(status().isNotFound());
    }

    // ──────────────────────────────────────────────
    // DELETE /api/juegos/{id}
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("DELETE /api/juegos/{id} - debe retornar 204 cuando existe")
    void desactivar_debeRetornar204_cuandoExiste() throws Exception {
        // Given
        doNothing().when(juegoService).desactivar(1L);

        // When / Then
        mockMvc.perform(delete("/api/juegos/1"))
                .andExpect(status().isNoContent());

        verify(juegoService).desactivar(1L);
    }

    @Test
    @DisplayName("DELETE /api/juegos/{id} - debe retornar 404 cuando no existe")
    void desactivar_debeRetornar404_cuandoNoExiste() throws Exception {
        // Given
        doThrow(new JuegoNotFoundException(99L)).when(juegoService).desactivar(99L);

        // When / Then
        mockMvc.perform(delete("/api/juegos/99"))
                .andExpect(status().isNotFound());
    }

    // ──────────────────────────────────────────────
    // GET /api/juegos (listar activos)
    // ──────────────────────────────────────────────

    @Test
    @DisplayName("GET /api/juegos - debe retornar 200 con lista de juegos activos")
    void listarActivos_debeRetornar200_conLista() throws Exception {
        // Given
        JuegoResponseDTO dto2 = new JuegoResponseDTO();
        dto2.setId(2L);
        dto2.setNombre("CS2");
        dto2.setGenero("FPS");
        dto2.setModalidad("5v5");
        dto2.setJugadoresPorEquipo(5);
        dto2.setEstado(true);

        when(juegoService.listarActivos()).thenReturn(List.of(responseDTO, dto2));

        // When / Then
        mockMvc.perform(get("/api/juegos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].nombre").value("Valorant"))
                .andExpect(jsonPath("$[1].nombre").value("CS2"));
    }
}
