package com.esports.game_service.controller;


import com.esports.game_service.dto.JuegoRequestDTO;
import com.esports.game_service.dto.JuegoResponseDTO;
import com.esports.game_service.service.JuegoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//Aqui se reciben las peticiones  HTTP
@RestController
@RequestMapping("/api/juegos")
@Tag(name = "Juegos", description = "Gestion del catalogo de videojuegos competitivos")
public class JuegoController {

    private final JuegoService juegoService;

    public JuegoController(JuegoService juegoService) {
        this.juegoService = juegoService;
    }

    //POST -> Crear juegos
    @Operation(summary = "Crear un nuevo juego", description = "Registra un videojuego en el catalogo. El nombre debe ser unico.")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Juego creado exitosamente",
                    content = @Content(examples = @ExampleObject(value = """
                            {"id":1,"nombre":"League of Legends","genero":"MOBA","modalidad":"5v5","jugadoresPorEquipo":5,"estado":true}"""))),
            @ApiResponse(responseCode = "400", description = "Datos de entrada invalidos"),
            @ApiResponse(responseCode = "500", description = "El nombre del juego ya existe")
    })
    @PostMapping
    public ResponseEntity<JuegoResponseDTO> crear(@Valid @RequestBody JuegoRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(juegoService.crear(dto));
    }

    //GET -> listar juegos activos
    @Operation(summary = "Listar juegos activos", description = "Retorna todos los juegos con estado activo (true).")
    @ApiResponses({@ApiResponse(responseCode = "200", description = "Lista retornada correctamente")})
    @GetMapping
    public ResponseEntity<List<JuegoResponseDTO>> listarActivos() {
        return ResponseEntity.ok(juegoService.listarActivos());
    }

    //GET -> buscar por ID
    @Operation(summary = "Buscar juego por ID", description = "Retorna un juego especifico por su identificador.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Juego encontrado"),
            @ApiResponse(responseCode = "404", description = "Juego no encontrado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<JuegoResponseDTO> buscar(
            @Parameter(description = "ID del juego", example = "1") @PathVariable Long id) {
        return ResponseEntity.ok(juegoService.buscarPorId(id));
    }

    //PUT -> actualizar juego
    @Operation(summary = "Actualizar juego", description = "Modifica los datos de un juego existente.")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Juego actualizado correctamente"),
            @ApiResponse(responseCode = "404", description = "Juego no encontrado"),
            @ApiResponse(responseCode = "400", description = "Datos invalidos")
    })
    @PutMapping("/{id}")
    public ResponseEntity<JuegoResponseDTO> actualizar(
            @Parameter(description = "ID del juego a actualizar", example = "1") @PathVariable Long id,
            @Valid @RequestBody JuegoRequestDTO dto) {
        return ResponseEntity.ok(juegoService.actualizar(id, dto));
    }

    //DELETE -> Desactivar juego
    @Operation(summary = "Desactivar juego", description = "Cambia el estado del juego a inactivo (false). No elimina el registro de la base de datos.")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Juego desactivado correctamente"),
            @ApiResponse(responseCode = "404", description = "Juego no encontrado")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> desactivar(
            @Parameter(description = "ID del juego a desactivar", example = "1") @PathVariable Long id) {
        juegoService.desactivar(id);
        return ResponseEntity.noContent().build();
    }
}
