package com.esports.team_service.service;

import com.esports.team_service.client.UsuarioClient;
import com.esports.team_service.dto.EquipoRequestDTO;
import com.esports.team_service.dto.EquipoResponseDTO;
import com.esports.team_service.dto.MiembroRequestDTO;
import com.esports.team_service.dto.MiembroResponseDTO;
import com.esports.team_service.model.Equipo;
import com.esports.team_service.model.MiembroEquipo;
import com.esports.team_service.repository.EquipoRepository;
import com.esports.team_service.repository.MiembroEquipoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Pruebas unitarias de TeamService.
 * UsuarioClient se simula por completo: nunca se hace una llamada HTTP real a
 * user-service durante estas pruebas.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("TeamService - pruebas unitarias")
class TeamServiceTest {

    @Mock
    private EquipoRepository equipoRepository;

    @Mock
    private MiembroEquipoRepository miembroRepository;

    @Mock
    private UsuarioClient usuarioClient;

    @InjectMocks
    private TeamService teamService;

    private EquipoRequestDTO requestDTO;
    private Equipo equipoGuardado;

    @BeforeEach
    void setUp() {
        requestDTO = new EquipoRequestDTO();
        requestDTO.setNombre("Dragones FC");
        requestDTO.setCapitanId(1L);
        requestDTO.setJuegoPrincipalId(5L);

        equipoGuardado = new Equipo();
        equipoGuardado.setId(10L);
        equipoGuardado.setNombre("Dragones FC");
        equipoGuardado.setCapitanId(1L);
        equipoGuardado.setJuegoPrincipalId(5L);
        equipoGuardado.setEstado(true);
    }

    @Test
    @DisplayName("crear() debe crear el equipo y agregar al capitan como miembro, si el capitan esta activo")
    void crear_conCapitanActivo_creaElEquipoYElMiembroCapitan() {
        // Given
        when(usuarioClient.usuarioExisteYEstaActivo(1L)).thenReturn(true);
        when(equipoRepository.save(any(Equipo.class))).thenReturn(equipoGuardado);
        when(miembroRepository.findByEquipoId(10L)).thenReturn(Collections.emptyList());

        // When
        EquipoResponseDTO resultado = teamService.crear(requestDTO);

        // Then
        assertThat(resultado.getId()).isEqualTo(10L);
        verify(miembroRepository).save(argThat(m ->
                m.getEquipoId().equals(10L) &&
                m.getUsuarioId().equals(1L) &&
                m.getRolDentroEquipo().equals("CAPITAN")
        ));
    }

    @Test
    @DisplayName("crear() debe fallar si el capitan no existe o esta inactivo en user-service")
    void crear_conCapitanInactivo_lanzaExcepcion() {
        when(usuarioClient.usuarioExisteYEstaActivo(1L)).thenReturn(false);

        assertThatThrownBy(() -> teamService.crear(requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("capitán no existe o está inactivo");

        verify(equipoRepository, never()).save(any());
    }

    @Test
    @DisplayName("agregarMiembro() debe fallar si el equipo esta inactivo")
    void agregarMiembro_conEquipoInactivo_lanzaExcepcion() {
        equipoGuardado.setEstado(false);
        when(equipoRepository.findById(10L)).thenReturn(Optional.of(equipoGuardado));

        MiembroRequestDTO miembroDto = new MiembroRequestDTO();
        miembroDto.setUsuarioId(2L);
        miembroDto.setRolDentroEquipo("JUGADOR");

        assertThatThrownBy(() -> teamService.agregarMiembro(10L, miembroDto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("equipo está inactivo");
    }

    @Test
    @DisplayName("agregarMiembro() debe fallar si el usuario no existe o esta inactivo")
    void agregarMiembro_conUsuarioInactivo_lanzaExcepcion() {
        when(equipoRepository.findById(10L)).thenReturn(Optional.of(equipoGuardado));
        when(usuarioClient.usuarioExisteYEstaActivo(2L)).thenReturn(false);

        MiembroRequestDTO miembroDto = new MiembroRequestDTO();
        miembroDto.setUsuarioId(2L);
        miembroDto.setRolDentroEquipo("JUGADOR");

        assertThatThrownBy(() -> teamService.agregarMiembro(10L, miembroDto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("usuario no existe o está inactivo");
    }

    @Test
    @DisplayName("agregarMiembro() debe fallar si el jugador ya pertenece al equipo")
    void agregarMiembro_conJugadorYaEnElEquipo_lanzaExcepcion() {
        when(equipoRepository.findById(10L)).thenReturn(Optional.of(equipoGuardado));
        when(usuarioClient.usuarioExisteYEstaActivo(2L)).thenReturn(true);
        when(miembroRepository.findByEquipoIdAndUsuarioId(10L, 2L))
                .thenReturn(Optional.of(new MiembroEquipo(1L, 10L, 2L, "JUGADOR")));

        MiembroRequestDTO miembroDto = new MiembroRequestDTO();
        miembroDto.setUsuarioId(2L);
        miembroDto.setRolDentroEquipo("JUGADOR");

        assertThatThrownBy(() -> teamService.agregarMiembro(10L, miembroDto))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("ya pertenece a este equipo");

        verify(miembroRepository, never()).save(any());
    }

    @Test
    @DisplayName("agregarMiembro() debe guardar el nuevo miembro cuando todas las validaciones pasan")
    void agregarMiembro_conDatosValidos_agregaElMiembro() {
        when(equipoRepository.findById(10L)).thenReturn(Optional.of(equipoGuardado));
        when(usuarioClient.usuarioExisteYEstaActivo(2L)).thenReturn(true);
        when(miembroRepository.findByEquipoIdAndUsuarioId(10L, 2L)).thenReturn(Optional.empty());
        when(miembroRepository.save(any(MiembroEquipo.class))).thenAnswer(inv -> {
            MiembroEquipo m = inv.getArgument(0);
            m.setId(99L);
            return m;
        });

        MiembroRequestDTO miembroDto = new MiembroRequestDTO();
        miembroDto.setUsuarioId(2L);
        miembroDto.setRolDentroEquipo("JUGADOR");

        MiembroResponseDTO resultado = teamService.agregarMiembro(10L, miembroDto);

        assertThat(resultado.getId()).isEqualTo(99L);
        assertThat(resultado.getRolDentroEquipo()).isEqualTo("JUGADOR");
    }

    @Test
    @DisplayName("desactivar() debe poner estado=false y guardar el equipo")
    void desactivar_conIdExistente_marcaInactivo() {
        when(equipoRepository.findById(10L)).thenReturn(Optional.of(equipoGuardado));

        teamService.desactivar(10L);

        verify(equipoRepository).save(argThat(e -> !e.getEstado()));
    }

    @Test
    @DisplayName("existeYEstaActivo() debe devolver false si el equipo no existe")
    void existeYEstaActivo_conIdInexistente_devuelveFalse() {
        when(equipoRepository.findById(404L)).thenReturn(Optional.empty());

        assertThat(teamService.existeYEstaActivo(404L)).isFalse();
    }

    @Test
    @DisplayName("buscarPorId() debe lanzar excepcion si el equipo no existe")
    void buscarPorId_conIdInexistente_lanzaExcepcion() {
        when(equipoRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> teamService.buscarPorId(404L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Equipo no encontrado");
    }
}
