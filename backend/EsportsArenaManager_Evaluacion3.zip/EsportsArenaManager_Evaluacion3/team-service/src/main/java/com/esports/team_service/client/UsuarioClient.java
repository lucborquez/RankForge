package com.esports.team_service.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

// Cliente REST hacia user-service usando WebClient (no bloqueante),
// con timeout explícito y manejo diferenciado de errores remotos.
@Component
public class UsuarioClient {

    private static final Logger log = LoggerFactory.getLogger(UsuarioClient.class);
    private static final Duration TIMEOUT = Duration.ofSeconds(3);

    private final WebClient webClient;

    public UsuarioClient(@Value("${user.service.url}") String userServiceUrl) {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(TIMEOUT);

        this.webClient = WebClient.builder()
                .baseUrl(userServiceUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    // Consulta a user-service si el usuario existe y está activo
    public boolean usuarioExisteYEstaActivo(Long usuarioId) {
        try {
            Boolean activo = webClient.get()
                    .uri("/api/usuarios/{id}/activo", usuarioId)
                    .retrieve()
                    .bodyToMono(Boolean.class)
                    .block(TIMEOUT);
            return Boolean.TRUE.equals(activo);
        } catch (WebClientResponseException.NotFound e) {
            log.warn("Usuario {} no existe en user-service", usuarioId);
            return false;
        } catch (Exception e) {
            log.error("Error consultando user-service para usuarioId {}: {}", usuarioId, e.getMessage());
            return false;
        }
    }
}
