package com.esports.sanction_service.service;

import com.esports.sanction_service.dto.SancionRequestDTO;
import com.esports.sanction_service.dto.SancionResponseDTO;
import com.esports.sanction_service.exception.SancionNotFoundException;
import com.esports.sanction_service.model.Sancion;
import com.esports.sanction_service.repository.SancionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("SancionService - pruebas unitarias")
class SancionServiceTest {

    @Mock
    private SancionRepository sancionRepository;

    @InjectMocks
    private SancionService sancionService;

    private SancionRequestDTO requestValido;

    @BeforeEach
    void setUp() {
        requestValido = new SancionRequestDTO();
        requestValido.setUsuarioId(5L);
        requestValido.setMotivo("Insultos durante la partida");
        requestValido.setSeveridad("grave");
        requestValido.setFechaInicio(LocalDate.of(2026, 7, 1));
        requestValido.setFechaFin(LocalDate.of(2026, 7, 15));
    }

    @Test
    @DisplayName("crear() debe fallar si no se indica usuarioId ni equipoId")
    void crear_sinUsuarioNiEquipo_lanzaExcepcion() {
        requestValido.setUsuarioId(null);

        assertThatThrownBy(() -> sancionService.crear(requestValido))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Debe indicar un usuarioId o equipoId");

        verify(sancionRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe fallar si la fecha fin es anterior a la fecha inicio")
    void crear_conFechaFinAnterior_lanzaExcepcion() {
        requestValido.setFechaFin(LocalDate.of(2026, 6, 30)); // antes del inicio (07-01)

        assertThatThrownBy(() -> sancionService.crear(requestValido))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("fecha de fin debe ser posterior");

        verify(sancionRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe guardar la sancion con la severidad en mayusculas y estado=true")
    void crear_conDatosValidos_creaLaSancionActiva() {
        when(sancionRepository.save(any(Sancion.class))).thenAnswer(inv -> {
            Sancion s = inv.getArgument(0);
            s.setId(1L);
            return s;
        });

        SancionResponseDTO resultado = sancionService.crear(requestValido);

        assertThat(resultado.getId()).isEqualTo(1L);
        assertThat(resultado.getSeveridad()).isEqualTo("GRAVE");
        assertThat(resultado.getEstado()).isTrue();
    }

    @Test
    @DisplayName("tieneSancionActiva() debe devolver true si existe al menos una sancion activa")
    void tieneSancionActiva_conSancionVigente_devuelveTrue() {
        Sancion activa = new Sancion();
        activa.setEstado(true);
        when(sancionRepository.findByUsuarioIdAndEstadoTrue(5L)).thenReturn(List.of(activa));

        assertThat(sancionService.tieneSancionActiva(5L)).isTrue();
    }

    @Test
    @DisplayName("tieneSancionActiva() debe devolver false si no hay sanciones activas")
    void tieneSancionActiva_sinSancionVigente_devuelveFalse() {
        when(sancionRepository.findByUsuarioIdAndEstadoTrue(5L)).thenReturn(Collections.emptyList());

        assertThat(sancionService.tieneSancionActiva(5L)).isFalse();
    }

    @Test
    @DisplayName("actualizar() no permite modificar una sancion ya cerrada")
    void actualizar_conSancionCerrada_lanzaExcepcion() {
        Sancion cerrada = new Sancion();
        cerrada.setId(1L);
        cerrada.setEstado(false);

        when(sancionRepository.findById(1L)).thenReturn(Optional.of(cerrada));

        assertThatThrownBy(() -> sancionService.actualizar(1L, requestValido))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("sancion cerrada");
    }

    @Test
    @DisplayName("cerrar() debe fallar si la sancion ya esta cerrada")
    void cerrar_conSancionYaCerrada_lanzaExcepcion() {
        Sancion cerrada = new Sancion();
        cerrada.setId(1L);
        cerrada.setEstado(false);

        when(sancionRepository.findById(1L)).thenReturn(Optional.of(cerrada));

        assertThatThrownBy(() -> sancionService.cerrar(1L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("ya esta cerrada");
    }

    @Test
    @DisplayName("cerrar() debe poner estado=false cuando la sancion esta activa")
    void cerrar_conSancionActiva_laCierra() {
        Sancion activa = new Sancion();
        activa.setId(1L);
        activa.setEstado(true);

        when(sancionRepository.findById(1L)).thenReturn(Optional.of(activa));
        when(sancionRepository.save(any(Sancion.class))).thenAnswer(inv -> inv.getArgument(0));

        SancionResponseDTO resultado = sancionService.cerrar(1L);

        assertThat(resultado.getEstado()).isFalse();
    }

    @Test
    @DisplayName("buscarPorId() debe lanzar SancionNotFoundException si no existe")
    void buscarPorId_conIdInexistente_lanzaNotFound() {
        when(sancionRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> sancionService.buscarPorId(404L))
                .isInstanceOf(SancionNotFoundException.class);
    }
}
