package com.esports.user_service.service;

import com.esports.user_service.dto.UsuarioRequestDTO;
import com.esports.user_service.dto.UsuarioResponseDTO;
import com.esports.user_service.exception.UsuarioNotFoundException;
import com.esports.user_service.model.Usuario;
import com.esports.user_service.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("UsuarioService - pruebas unitarias")
class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @InjectMocks
    private UsuarioService usuarioService;

    private Usuario usuarioExistente;
    private UsuarioRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        usuarioExistente = new Usuario();
        usuarioExistente.setId(1L);
        usuarioExistente.setNombre("Lucas Borquez");
        usuarioExistente.setApodo("lucasb");
        usuarioExistente.setEmail("lucas@esports.com");
        usuarioExistente.setRol("JUGADOR");
        usuarioExistente.setEstado(true);
        usuarioExistente.setFechaRegistro(LocalDate.now());

        requestDTO = new UsuarioRequestDTO();
        requestDTO.setNombre("Lucas Borquez");
        requestDTO.setApodo("lucasb");
        requestDTO.setEmail("lucas@esports.com");
        requestDTO.setRol("JUGADOR");
    }

    @Test
    @DisplayName("crear() debe guardar el usuario cuando apodo y email estan disponibles")
    void crear_conDatosDisponibles_creaElUsuario() {
        when(usuarioRepository.findByApodo("lucasb")).thenReturn(Optional.empty());
        when(usuarioRepository.findByEmail("lucas@esports.com")).thenReturn(Optional.empty());
        when(usuarioRepository.save(any(Usuario.class))).thenReturn(usuarioExistente);

        UsuarioResponseDTO resultado = usuarioService.crear(requestDTO);

        assertThat(resultado.getApodo()).isEqualTo("lucasb");
        verify(usuarioRepository).save(any(Usuario.class));
    }

    @Test
    @DisplayName("crear() debe fallar si el apodo ya esta en uso")
    void crear_conApodoDuplicado_lanzaExcepcion() {
        when(usuarioRepository.findByApodo("lucasb")).thenReturn(Optional.of(usuarioExistente));

        assertThatThrownBy(() -> usuarioService.crear(requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Apodo");

        verify(usuarioRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe fallar si el email ya esta en uso, aunque el apodo este libre")
    void crear_conEmailDuplicado_lanzaExcepcion() {
        when(usuarioRepository.findByApodo("lucasb")).thenReturn(Optional.empty());
        when(usuarioRepository.findByEmail("lucas@esports.com")).thenReturn(Optional.of(usuarioExistente));

        assertThatThrownBy(() -> usuarioService.crear(requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("email");

        verify(usuarioRepository, never()).save(any());
    }

    @Test
    @DisplayName("buscarPorId() debe lanzar UsuarioNotFoundException si no existe")
    void buscarPorId_conIdInexistente_lanzaNotFound() {
        when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> usuarioService.buscarPorId(99L))
                .isInstanceOf(UsuarioNotFoundException.class);
    }

    @Test
    @DisplayName("desactivar() debe poner estado=false y guardar")
    void desactivar_conIdExistente_marcaInactivo() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioExistente));

        usuarioService.desactivar(1L);

        verify(usuarioRepository).save(argThat(u -> !u.getEstado()));
    }

    @Test
    @DisplayName("existeYActivo() debe devolver true solo si el usuario existe y esta activo")
    void existeYActivo_conUsuarioActivo_devuelveTrue() {
        when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioExistente));

        assertThat(usuarioService.existeYActivo(1L)).isTrue();
    }

    @Test
    @DisplayName("existeYActivo() debe devolver false si el usuario no existe")
    void existeYActivo_conUsuarioInexistente_devuelveFalse() {
        when(usuarioRepository.findById(50L)).thenReturn(Optional.empty());

        assertThat(usuarioService.existeYActivo(50L)).isFalse();
    }

    @Test
    @DisplayName("listarPorRol() debe devolver solo los usuarios con ese rol")
    void listarPorRol_devuelveListaFiltrada() {
        when(usuarioRepository.findByRol("JUGADOR")).thenReturn(List.of(usuarioExistente));

        List<UsuarioResponseDTO> resultado = usuarioService.listarPorRol("JUGADOR");

        assertThat(resultado).hasSize(1);
        assertThat(resultado.get(0).getRol()).isEqualTo("JUGADOR");
    }
}
