package com.esports.match_service.service;

import com.esports.match_service.client.InscripcionClient;
import com.esports.match_service.client.TorneoClient;
import com.esports.match_service.dto.PartidaRequestDTO;
import com.esports.match_service.dto.PartidaResponseDTO;
import com.esports.match_service.exception.PartidaNotFoundException;
import com.esports.match_service.model.Partida;
import com.esports.match_service.repository.PartidaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("PartidaService - pruebas unitarias")
class PartidaServiceTest {

    @Mock
    private PartidaRepository partidaRepository;

    @Mock
    private TorneoClient torneoClient;

    @Mock
    private InscripcionClient inscripcionClient;

    @InjectMocks
    private PartidaService partidaService;

    private PartidaRequestDTO requestDTO;

    @BeforeEach
    void setUp() {
        requestDTO = new PartidaRequestDTO();
        requestDTO.setTorneoId(1L);
        requestDTO.setParticipanteAId(10L);
        requestDTO.setParticipanteBId(20L);
        requestDTO.setRonda("OCTAVOS");
        requestDTO.setFechaHora("2026-07-10 18:00");
    }

    @Test
    @DisplayName("crear() debe guardar la partida cuando el torneo existe y ambos participantes estan inscritos")
    void crear_conDatosValidos_creaLaPartida() {
        when(torneoClient.torneoExiste(1L)).thenReturn(true);
        when(inscripcionClient.participanteInscrito(1L, 10L)).thenReturn(true);
        when(inscripcionClient.participanteInscrito(1L, 20L)).thenReturn(true);
        when(partidaRepository.existsByTorneoIdAndParticipanteAIdAndParticipanteBIdAndRonda(
                1L, 10L, 20L, "OCTAVOS")).thenReturn(false);
        when(partidaRepository.save(any(Partida.class))).thenAnswer(inv -> {
            Partida p = inv.getArgument(0);
            p.setId(50L);
            return p;
        });

        PartidaResponseDTO resultado = partidaService.crear(requestDTO);

        assertThat(resultado.getId()).isEqualTo(50L);
        assertThat(resultado.getEstado()).isEqualTo("PROGRAMADA");
    }

    @Test
    @DisplayName("crear() debe fallar si el torneo no existe")
    void crear_conTorneoInexistente_lanzaExcepcion() {
        when(torneoClient.torneoExiste(1L)).thenReturn(false);

        assertThatThrownBy(() -> partidaService.crear(requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("El torneo no existe");

        verify(partidaRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe fallar si el participante A no esta inscrito")
    void crear_conParticipanteANoInscrito_lanzaExcepcion() {
        when(torneoClient.torneoExiste(1L)).thenReturn(true);
        when(inscripcionClient.participanteInscrito(1L, 10L)).thenReturn(false);

        assertThatThrownBy(() -> partidaService.crear(requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("participante A no está inscrito");
    }

    @Test
    @DisplayName("crear() debe fallar si el participante B no esta inscrito")
    void crear_conParticipanteBNoInscrito_lanzaExcepcion() {
        when(torneoClient.torneoExiste(1L)).thenReturn(true);
        when(inscripcionClient.participanteInscrito(1L, 10L)).thenReturn(true);
        when(inscripcionClient.participanteInscrito(1L, 20L)).thenReturn(false);

        assertThatThrownBy(() -> partidaService.crear(requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("participante B no está inscrito");
    }

    @Test
    @DisplayName("crear() debe fallar si ya existe el mismo enfrentamiento en la misma ronda")
    void crear_conEnfrentamientoDuplicado_lanzaExcepcion() {
        when(torneoClient.torneoExiste(1L)).thenReturn(true);
        when(inscripcionClient.participanteInscrito(1L, 10L)).thenReturn(true);
        when(inscripcionClient.participanteInscrito(1L, 20L)).thenReturn(true);
        when(partidaRepository.existsByTorneoIdAndParticipanteAIdAndParticipanteBIdAndRonda(
                1L, 10L, 20L, "OCTAVOS")).thenReturn(true);

        assertThatThrownBy(() -> partidaService.crear(requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Ya existe este enfrentamiento");
    }

    @Test
    @DisplayName("actualizar() no permite modificar una partida ya finalizada")
    void actualizar_conPartidaFinalizada_lanzaExcepcion() {
        Partida partida = new Partida();
        partida.setId(1L);
        partida.setEstado("FINALIZADA");

        when(partidaRepository.findById(1L)).thenReturn(Optional.of(partida));

        assertThatThrownBy(() -> partidaService.actualizar(1L, requestDTO))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("cancelada o finalizada");
    }

    @Test
    @DisplayName("cancelar() debe fallar si la partida ya esta cancelada")
    void cancelar_conPartidaYaCancelada_lanzaExcepcion() {
        Partida partida = new Partida();
        partida.setId(1L);
        partida.setEstado("CANCELADA");

        when(partidaRepository.findById(1L)).thenReturn(Optional.of(partida));

        assertThatThrownBy(() -> partidaService.cancelar(1L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("ya está cancelada");
    }

    @Test
    @DisplayName("cancelar() debe cambiar el estado a CANCELADA cuando la partida esta programada")
    void cancelar_conPartidaProgramada_laCancela() {
        Partida partida = new Partida();
        partida.setId(1L);
        partida.setEstado("PROGRAMADA");

        when(partidaRepository.findById(1L)).thenReturn(Optional.of(partida));
        when(partidaRepository.save(any(Partida.class))).thenAnswer(inv -> inv.getArgument(0));

        PartidaResponseDTO resultado = partidaService.cancelar(1L);

        assertThat(resultado.getEstado()).isEqualTo("CANCELADA");
    }

    @Test
    @DisplayName("buscarPorId() debe lanzar PartidaNotFoundException si no existe")
    void buscarPorId_conIdInexistente_lanzaNotFound() {
        when(partidaRepository.findById(404L)).thenReturn(Optional.empty());

        assertThatThrownBy(() -> partidaService.buscarPorId(404L))
                .isInstanceOf(PartidaNotFoundException.class);
    }
}
