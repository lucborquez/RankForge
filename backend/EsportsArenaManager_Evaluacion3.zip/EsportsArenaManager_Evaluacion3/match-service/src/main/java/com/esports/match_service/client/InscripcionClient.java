package com.esports.match_service.client;

import lombok.Data;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;
import java.util.Arrays;
import java.util.List;

// Cliente REST hacia registration-service usando WebClient (no bloqueante), con timeout.
@Component
public class InscripcionClient {

    private static final Logger log = LoggerFactory.getLogger(InscripcionClient.class);
    private static final Duration TIMEOUT = Duration.ofSeconds(3);

    private final WebClient webClient;

    public InscripcionClient(@Value("${registration.service.url}") String registrationServiceUrl) {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(TIMEOUT);

        this.webClient = WebClient.builder()
                .baseUrl(registrationServiceUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    // Verifica si un participante está inscrito en el torneo
    public boolean participanteInscrito(Long torneoId, Long participanteId) {
        try {
            InscripcionDTO[] inscripciones = webClient.get()
                    .uri("/api/inscripciones/torneo/{torneoId}", torneoId)
                    .retrieve()
                    .bodyToMono(InscripcionDTO[].class)
                    .block(TIMEOUT);

            if (inscripciones == null) return false;

            List<InscripcionDTO> lista = Arrays.asList(inscripciones);
            return lista.stream().anyMatch(i ->
                    participanteId.equals(i.getJugadorId()) ||
                            participanteId.equals(i.getEquipoId()));
        } catch (WebClientResponseException.NotFound e) {
            log.warn("No hay inscripciones registradas para el torneo {}", torneoId);
            return false;
        } catch (Exception e) {
            log.error("Error consultando registration-service: {}", e.getMessage());
            return false;
        }
    }

    // DTO interno
    @Data
    public static class InscripcionDTO {
        private Long jugadorId;
        private Long equipoId;
        private String estado;
    }
}
