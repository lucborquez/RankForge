package com.esports.tournament_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TournamentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
