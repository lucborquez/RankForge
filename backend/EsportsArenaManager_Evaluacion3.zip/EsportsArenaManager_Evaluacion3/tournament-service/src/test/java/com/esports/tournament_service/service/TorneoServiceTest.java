package com.esports.tournament_service.service;

import com.esports.tournament_service.client.JuegoClient;
import com.esports.tournament_service.dto.CambioEstadoDTO;
import com.esports.tournament_service.dto.TorneoRequestDTO;
import com.esports.tournament_service.dto.TorneoResponseDTO;
import com.esports.tournament_service.model.Torneo;
import com.esports.tournament_service.repository.TorneoRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Pruebas unitarias de TorneoService.
 *
 * Aqui hay DOS dependencias para simular:
 *  - TorneoRepository: el acceso a datos (JPA).
 *  - JuegoClient: la comunicacion con game-service (otro microservicio). En el test
 *    NUNCA se hace una llamada HTTP real; se simula la respuesta de juegoExiste()
 *    para poder probar la regla de negocio sin depender de que game-service este
 *    levantado.
 */
@ExtendWith(MockitoExtension.class)
@DisplayName("TorneoService - pruebas unitarias")
class TorneoServiceTest {

    @Mock
    private TorneoRepository torneoRepository;

    @Mock
    private JuegoClient juegoClient;

    @InjectMocks
    private TorneoService torneoService;

    private TorneoRequestDTO requestValido;

    @BeforeEach
    void setUp() {
        requestValido = new TorneoRequestDTO();
        requestValido.setNombre("Copa Verano");
        requestValido.setJuegoId(1L);
        requestValido.setFechaCierreInscripcion("2026-07-01");
        requestValido.setFechaInicio("2026-07-05");
        requestValido.setFechaFin("2026-07-10");
        requestValido.setCupoMaximo(16);
        requestValido.setModalidad("5v5");
    }

    @Test
    @DisplayName("crear() debe guardar el torneo en BORRADOR cuando el juego existe y las fechas son validas")
    void crear_conDatosValidos_creaTorneoEnBorrador() {
        // Given
        when(juegoClient.juegoExiste(1L)).thenReturn(true);
        when(torneoRepository.save(any(Torneo.class))).thenAnswer(inv -> {
            Torneo t = inv.getArgument(0);
            t.setId(10L);
            return t;
        });

        // When
        TorneoResponseDTO resultado = torneoService.crear(requestValido);

        // Then
        assertThat(resultado.getId()).isEqualTo(10L);
        assertThat(resultado.getEstado()).isEqualTo("BORRADOR");
        verify(juegoClient).juegoExiste(1L);
    }

    @Test
    @DisplayName("crear() debe fallar si game-service indica que el juego no existe")
    void crear_conJuegoInexistente_lanzaExcepcion() {
        when(juegoClient.juegoExiste(1L)).thenReturn(false);

        assertThatThrownBy(() -> torneoService.crear(requestValido))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("El juego no existe");

        verify(torneoRepository, never()).save(any());
    }

    @Test
    @DisplayName("crear() debe fallar si la fecha de inicio NO es posterior al cierre de inscripcion")
    void crear_conFechaInicioInvalida_lanzaExcepcion() {
        when(juegoClient.juegoExiste(1L)).thenReturn(true);
        requestValido.setFechaInicio("2026-06-30"); // antes del cierre de inscripcion (07-01)

        assertThatThrownBy(() -> torneoService.crear(requestValido))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("fecha de inicio debe ser posterior");
    }

    @Test
    @DisplayName("crear() debe fallar si la fecha fin NO es posterior a la fecha inicio")
    void crear_conFechaFinInvalida_lanzaExcepcion() {
        when(juegoClient.juegoExiste(1L)).thenReturn(true);
        requestValido.setFechaFin("2026-07-04"); // antes de la fecha inicio (07-05)

        assertThatThrownBy(() -> torneoService.crear(requestValido))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("fecha de fin debe ser posterior");
    }

    @Test
    @DisplayName("cambiarEstado() permite la transicion BORRADOR -> ABIERTO")
    void cambiarEstado_transicionValida_actualizaEstado() {
        Torneo torneo = new Torneo();
        torneo.setId(1L);
        torneo.setEstado("BORRADOR");

        when(torneoRepository.findById(1L)).thenReturn(Optional.of(torneo));
        when(torneoRepository.save(any(Torneo.class))).thenAnswer(inv -> inv.getArgument(0));

        CambioEstadoDTO cambio = new CambioEstadoDTO();
        cambio.setEstado("ABIERTO");

        TorneoResponseDTO resultado = torneoService.cambiarEstado(1L, cambio);

        assertThat(resultado.getEstado()).isEqualTo("ABIERTO");
    }

    @Test
    @DisplayName("cambiarEstado() rechaza una transicion invalida, ej. FINALIZADO -> ABIERTO")
    void cambiarEstado_transicionInvalida_lanzaExcepcion() {
        Torneo torneo = new Torneo();
        torneo.setId(1L);
        torneo.setEstado("FINALIZADO");

        when(torneoRepository.findById(1L)).thenReturn(Optional.of(torneo));

        CambioEstadoDTO cambio = new CambioEstadoDTO();
        cambio.setEstado("ABIERTO");

        assertThatThrownBy(() -> torneoService.cambiarEstado(1L, cambio))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("Transición de estado inválida");

        verify(torneoRepository, never()).save(any());
    }

    @Test
    @DisplayName("actualizar() no permite modificar un torneo EN_CURSO")
    void actualizar_conTorneoEnCurso_lanzaExcepcion() {
        Torneo torneo = new Torneo();
        torneo.setId(1L);
        torneo.setEstado("EN_CURSO");

        when(torneoRepository.findById(1L)).thenReturn(Optional.of(torneo));

        assertThatThrownBy(() -> torneoService.actualizar(1L, requestValido))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("torneo que está en curso");
    }

    @Test
    @DisplayName("torneoEstaAbierto() devuelve true solo si el estado es ABIERTO")
    void torneoEstaAbierto_devuelveElValorCorrecto() {
        Torneo abierto = new Torneo();
        abierto.setEstado("ABIERTO");
        when(torneoRepository.findById(1L)).thenReturn(Optional.of(abierto));

        assertThat(torneoService.torneoEstaAbierto(1L)).isTrue();
    }

    @Test
    @DisplayName("torneoEstaAbierto() devuelve false si el torneo no existe")
    void torneoEstaAbierto_conIdInexistente_devuelveFalse() {
        when(torneoRepository.findById(99L)).thenReturn(Optional.empty());

        assertThat(torneoService.torneoEstaAbierto(99L)).isFalse();
    }

    @Test
    @DisplayName("obtenerParaInscripcion() falla si el torneo no esta ABIERTO")
    void obtenerParaInscripcion_conTorneoNoAbierto_lanzaExcepcion() {
        Torneo cerrado = new Torneo();
        cerrado.setId(1L);
        cerrado.setEstado("CERRADO");
        when(torneoRepository.findById(1L)).thenReturn(Optional.of(cerrado));

        assertThatThrownBy(() -> torneoService.obtenerParaInscripcion(1L))
                .isInstanceOf(RuntimeException.class)
                .hasMessageContaining("no está abierto");
    }
}
