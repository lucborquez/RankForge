package com.esports.tournament_service.client;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

// Cliente REST hacia game-service usando WebClient (no bloqueante), con timeout.
@Component
public class JuegoClient {

    private static final Logger log = LoggerFactory.getLogger(JuegoClient.class);
    private static final Duration TIMEOUT = Duration.ofSeconds(3);

    private final WebClient webClient;

    public JuegoClient(@Value("${game.service.url}") String gameServiceUrl) {
        HttpClient httpClient = HttpClient.create()
                .responseTimeout(TIMEOUT);

        this.webClient = WebClient.builder()
                .baseUrl(gameServiceUrl)
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .build();
    }

    public boolean juegoExiste(Long juegoId) {
        try {
            webClient.get()
                    .uri("/api/juegos/{id}", juegoId)
                    .retrieve()
                    .toBodilessEntity()
                    .block(TIMEOUT);
            return true;
        } catch (WebClientResponseException.NotFound e) {
            log.warn("Juego {} no existe en game-service", juegoId);
            return false;
        } catch (Exception e) {
            log.error("Error consultando game-service para juegoId {}: {}", juegoId, e.getMessage());
            return false;
        }
    }
}
